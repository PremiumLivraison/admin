import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from 'react';
import { ClerkProvider, SignIn, SignUp, Show, useClerk } from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { shadcn } from '@clerk/themes';
import { QueryClient, QueryClientProvider, useQueryClient } from '@tanstack/react-query';
import { Link, Redirect, Route, Router as WouterRouter, Switch, useLocation, useParams } from 'wouter';
import {
  ArrowDownLeft, ArrowLeft, ArrowUpRight, Bike, CalendarDays, Check,
  ChevronLeft, CircleAlert, Clock3, Download, FileText, Filter,
  Home, LogOut, MapPin, Menu, Package, Plus, Search, Settings as SettingsIcon,
  Store, Wallet, X,
} from 'lucide-react';
import {
  getGetDashboardQueryKey, getGetMerchantQueryKey, getGetMerchantSummaryQueryKey,
  getGetOrderQueryKey, getGetReportsQueryKey, getGetSettingsQueryKey, getExportReportCsvQueryKey,
  getListMerchantsQueryKey, getListOrdersQueryKey, getListPaymentsQueryKey,
  useArchiveOrder, useCreateMerchant, useCreateOrder, useCreatePayment,
  useExportReportCsv, useGetDashboard, useGetMerchant, useGetMerchantSummary,
  useGetOrder, useGetOwner, useGetReports, useGetSettings, useListMerchants,
  useListOrders, useListPayments, useReversePayment, useStartBusinessWorkflow,
  useUpdateMerchant, useUpdateOrder, useUpdateSettings,
} from '@workspace/api-client-react';
import type {
  MerchantInput, OrderInput, OrderStatus, PaymentInput, SettingsInput,
} from '@workspace/api-client-react';
import './index.css';

const queryClient = new QueryClient({ defaultOptions: { queries: { staleTime: 15_000, retry: 1 } } });
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(window.location.hostname, import.meta.env.VITE_CLERK_PUBLISHABLE_KEY);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
function stripBase(path: string) { return basePath && path.startsWith(basePath) ? path.slice(basePath.length) || '/' : path; }

const appearance = {
  theme: shadcn,
  cssLayerName: 'clerk',
  options: { logoPlacement: 'inside' as const, logoLinkUrl: basePath || '/', logoImageUrl: `${window.location.origin}${basePath}/logo.svg` },
  variables: {
    colorPrimary: '#FFD400', colorForeground: '#F4F1E9', colorMutedForeground: '#A6A79F',
    colorDanger: '#F26B68', colorBackground: '#191B1D', colorInput: '#25282A',
    colorInputForeground: '#F4F1E9', colorNeutral: '#44484A', fontFamily: "'DM Sans', 'IBM Plex Sans Arabic', sans-serif",
    borderRadius: '14px',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-[#191b1d] rounded-2xl w-[440px] max-w-full overflow-hidden border border-[#303335]',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#f4f1e9] font-semibold', headerSubtitle: 'text-[#a6a79f]',
    socialButtonsBlockButtonText: 'text-[#f4f1e9]', formFieldLabel: 'text-[#d6d5ce]',
    footerActionLink: 'text-[#ffd400]', footerActionText: 'text-[#a6a79f]',
    dividerText: 'text-[#a6a79f]', identityPreviewEditButton: 'text-[#ffd400]',
    formFieldSuccessText: 'text-[#59c78c]', alertText: 'text-[#f4f1e9]',
    logoBox: 'rounded-xl', logoImage: 'rounded-xl', socialButtonsBlockButton: 'border-[#44484a] bg-[#222527]',
    formButtonPrimary: 'bg-[#ffd400] text-[#191b1d] hover:bg-[#ffe04b]',
    formFieldInput: 'bg-[#25282a] border-[#44484a] text-[#f4f1e9]',
    footerAction: 'text-[#a6a79f]', dividerLine: 'bg-[#44484a]', alert: 'bg-[#262728]',
    otpCodeFieldInput: 'bg-[#25282a] border-[#44484a]', formFieldRow: 'text-[#f4f1e9]', main: 'text-[#f4f1e9]',
  },
};

type IconType = typeof Home;
const navItems: { href: string; label: string; icon: IconType }[] = [
  { href: '/dashboard', label: 'الرئيسية', icon: Home },
  { href: '/orders', label: 'الطلبات', icon: Package },
  { href: '/merchants', label: 'التجار', icon: Store },
  { href: '/accounting', label: 'الحسابات', icon: Wallet },
  { href: '/settings', label: 'الإعدادات', icon: SettingsIcon },
];
const statusLabels: Record<string, string> = {
  new: 'جديد', ready: 'واجد للتوصيل', out_for_delivery: 'فطريق التوصيل',
  delivered: 'تسلّم', failed: 'ما تسلّمش', cancelled: 'ملغي',
  confirmed: 'مؤكد', reversed: 'مرجوع',
};
const statusColors: Record<string, string> = {
  new: 'amber', ready: 'cyan', out_for_delivery: 'blue', delivered: 'green',
  failed: 'red', cancelled: 'muted', confirmed: 'green', reversed: 'red',
};
const money = (centimes?: number | null) => new Intl.NumberFormat('ar-MA', { style: 'currency', currency: 'MAD', maximumFractionDigits: 2 }).format((centimes ?? 0) / 100);
const dateText = (value?: string | null) => value ? new Intl.DateTimeFormat('ar-MA', { day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(value)) : '—';
const today = () => new Date().toISOString().slice(0, 10);
const fromError = (error: unknown) => error instanceof Error ? error.message : 'وقع مشكل. عاود المحاولة.';

function Status({ value }: { value: string }) {
  return <span className={`status status-${statusColors[value] || 'muted'}`} data-testid={`status-${value}`}>{statusLabels[value] || value}</span>;
}
function PageTitle({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return <div className="page-title"><div><h1>{title}</h1>{subtitle && <p>{subtitle}</p>}</div>{action}</div>;
}
function Button({ children, variant = 'primary', ...props }: React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'quiet' | 'danger' }) {
  return <button className={`button button-${variant}`} {...props}>{children}</button>;
}
function Field({ label, children, className = '' }: { label: string; children: ReactNode; className?: string }) {
  return <label className={`field ${className}`}><span>{label}</span>{children}</label>;
}
function ErrorBox({ error, retry }: { error: unknown; retry?: () => void }) {
  return <div className="notice error-notice"><CircleAlert size={18} /><span>{fromError(error)}</span>{retry && <button onClick={retry}>عاود</button>}</div>;
}
function Loading({ rows = 4 }: { rows?: number }) {
  return <div className="skeleton-stack" aria-label="جاري التحميل">{Array.from({ length: rows }, (_, i) => <div className="skeleton" key={i} />)}</div>;
}
function Empty({ title, detail, action }: { title: string; detail: string; action?: ReactNode }) {
  return <div className="empty-state"><span className="empty-mark"><Package size={22} /></span><strong>{title}</strong><p>{detail}</p>{action}</div>;
}
function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const owner = useGetOwner();
  const activeTitle = navItems.find((item) => item.href === location)?.label ?? 'Premium Livreson';
  return <div className="app-shell" dir="rtl">
    <aside className="side-rail">
      <Link href="/dashboard" className="brand-lockup"><span className="brand-symbol"><Bike size={21} /></span><span><b>Premium</b><small>Livreson</small></span></Link>
      <div className="side-rule" />
      <span className="nav-caption">خدمة النهار</span>
      <nav>{navItems.map(({ href, label, icon: Icon }) => <Link href={href} key={href} className={`nav-link ${location === href ? 'active' : ''}`} data-testid={`nav-${href.replace('/', '')}`}><Icon size={18} /><span>{label}</span>{href === '/orders' && <span className="nav-dot" />}</Link>)}</nav>
      <div className="side-bottom"><span className="online-dot" /><span>خدامين ففاس</span><span className="side-time">11:00 — 13:00</span></div>
    </aside>
    <div className="main-column">
      <header className="topbar"><button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="فتح القائمة"><Menu size={20} /></button><div className="crumb"><span>Premium Livreson</span><ChevronLeft size={14} /><b>{activeTitle}</b></div><div className="top-user">{owner.data?.name && <span>{owner.data.name}</span>}<span className="user-avatar">{(owner.data?.name || 'PL').slice(0, 1)}</span></div></header>
      {menuOpen && <div className="mobile-menu-panel">{navItems.map(({ href, label, icon: Icon }) => <Link href={href} onClick={() => setMenuOpen(false)} key={href}><Icon size={18} />{label}</Link>)}</div>}
      <main className="page-content">{owner.isError && <ErrorBox error={owner.error} retry={() => owner.refetch()} />}{children}</main>
      <nav className="bottom-nav">{navItems.map(({ href, label, icon: Icon }) => <Link href={href} key={href} className={location === href ? 'selected' : ''}><Icon size={19} /><span>{label}</span></Link>)}</nav>
    </div>
  </div>;
}

function PublicHome() {
  return <div className="landing" dir="rtl"><div className="landing-top"><Link href="/" className="brand-lockup"><span className="brand-symbol"><Bike size={21} /></span><span><b>Premium</b><small>Livreson</small></span></Link><span className="owner-tag">خاص بمالك النشاط</span></div>
    <div className="landing-content"><div className="landing-copy animate-enter"><div className="eyebrow"><span className="live-dot" /> خدمة التوصيل ديال فاس</div><h1>نهارك واضح.<br /><em>طلباتك</em> تحت السيطرة.</h1><p>من تجميع الطلبات مع 11 حتى للتوصيل، كلشي مرتب فبلاصة وحدة. خدمة يومية سريعة وواضحة، بلا صداع الحساب.</p><Link className="button button-primary landing-cta" href="/sign-in"><span>دخول للوحة الخدمة</span><ArrowLeft size={17} /></Link><div className="landing-note"><span className="lock-glyph">●</span> الولوج خاص بصاحب Premium Livreson فقط</div></div>
      <div className="hero-visual animate-enter delay-2"><div className="orbit orbit-one" /><div className="orbit orbit-two" /><div className="route-line" /><div className="map-pin pin-one"><MapPin size={18} /></div><div className="map-pin pin-two"><MapPin size={18} /></div><div className="map-core"><div className="core-ring"><Bike size={42} /></div><span>فاس</span></div><div className="map-label label-top"><span className="label-dot" /> تجميع الطلبات <b>11:00 — 13:00</b></div><div className="map-label label-bottom"><span className="label-dot yellow" /> الانطلاق للتوصيل <b>من بعد 13:00</b></div><div className="visual-coord">34°02′N · 5°00′W</div></div></div>
    <div className="landing-footer"><span>Premium Livreson Manager</span><span>فاس، المغرب <i /> MAD</span></div>
  </div>;
}
function SignInPage() { return <div className="sign-in-screen" dir="rtl"><div className="sign-in-intro"><Link href="/" className="brand-lockup"><span className="brand-symbol"><Bike size={21} /></span><span><b>Premium</b><small>Livreson</small></span></Link><p>دخول آمن للمالك</p></div><SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} hideSignUp forceRedirectUrl={`${basePath}/dashboard`} /> <Link href="/" className="back-home"><ArrowLeft size={15} /> رجوع للموقع</Link></div>; }
function InvitationSignUpPage() {
  const ticket = new URLSearchParams(window.location.search).get('__clerk_ticket');
  if (!ticket) return <Redirect to="/" />;
  return <div className="sign-in-screen" dir="rtl"><div className="sign-in-intro"><Link href="/" className="brand-lockup"><span className="brand-symbol"><Bike size={21} /></span><span><b>Premium</b><small>Livreson</small></span></Link><p>قبول الدعوة الخاصة</p></div><SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} forceRedirectUrl={`${basePath}/dashboard`} /></div>;
}
function HomeRoute() { return <><Show when="signed-in"><Redirect to="/dashboard" /></Show><Show when="signed-out"><PublicHome /></Show></>; }
function Guard({ children }: { children: ReactNode }) { return <><Show when="signed-in"><Shell>{children}</Shell></Show><Show when="signed-out"><Redirect to="/" /></Show></>; }
function ClerkCacheInvalidator() {
  const { addListener } = useClerk(); const client = useQueryClient(); const prior = useRef<string | null | undefined>(undefined);
  useEffect(() => { const unsubscribe = addListener(({ user }) => { const id = user?.id ?? null; if (prior.current !== undefined && prior.current !== id) client.clear(); prior.current = id; }); return unsubscribe; }, [addListener, client]);
  return null;
}

function DashboardPage() {
  const [period, setPeriod] = useState<'day' | 'week' | 'month'>('day');
  const query = useGetDashboard({ period });
  const start = useStartBusinessWorkflow();
  const client = useQueryClient();
  const data = query.data;
  const begin = (mode: 'collection' | 'delivery') => {
    const title = mode === 'collection' ? 'بدا تجميع الطلبات؟' : 'بدا التوصيل؟';
    if (!window.confirm(title)) return;
    start.mutate({ data: { mode } }, { onSuccess: () => { client.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); client.invalidateQueries({ queryKey: getListOrdersQueryKey() }); } });
  };
  return <div className="animate-enter">
    <PageTitle title="نهارك فخدمتك" subtitle={data ? `نهار ${dateText(data.workflow.businessDate)} · هادي هي الصورة ديال الخدمة` : 'لوحة الخدمة اليومية'} action={<div className="period-switch">{(['day', 'week', 'month'] as const).map((p) => <button key={p} className={period === p ? 'chosen' : ''} onClick={() => setPeriod(p)}>{p === 'day' ? 'اليوم' : p === 'week' ? 'هاد السيمانة' : 'هاد الشهر'}</button>)}</div>} />
    {query.isLoading ? <Loading rows={6} /> : query.isError ? <ErrorBox error={query.error} retry={() => query.refetch()} /> : data && <>
      <section className="workflow-card">
        <div className="workflow-head"><div><span className="eyebrow small-eyebrow">البرنامج ديال اليوم</span><h2>من التجميع حتى لباب الزبون</h2></div><span className="workflow-date"><CalendarDays size={15} /> {dateText(data.workflow.businessDate)}</span></div>
        <div className="workflow-steps"><div className={`workflow-step ${data.workflow.collectionStartedAt ? 'done' : 'current'}`}><span className="step-index">{data.workflow.collectionStartedAt ? <Check size={15} /> : '01'}</span><div><b>تجميع الطلبات</b><small>{data.workflow.collectionStartedAt ? `بدا مع ${new Date(data.workflow.collectionStartedAt).toLocaleTimeString('ar-MA', { hour: '2-digit', minute: '2-digit' })}` : '11:00 — 13:00'}</small></div></div><div className="workflow-connector" /><div className={`workflow-step ${data.workflow.deliveryStartedAt ? 'done' : data.workflow.collectionStartedAt ? 'current' : ''}`}><span className="step-index">{data.workflow.deliveryStartedAt ? <Check size={15} /> : '02'}</span><div><b>بداية التوصيل</b><small>{data.workflow.deliveryStartedAt ? `بدا مع ${new Date(data.workflow.deliveryStartedAt).toLocaleTimeString('ar-MA', { hour: '2-digit', minute: '2-digit' })}` : 'من بعد 13:00'}</small></div></div></div>
        <div className="workflow-actions">{!data.workflow.collectionStartedAt && <Button onClick={() => begin('collection')} disabled={start.isPending}><Clock3 size={16} /> بدا تجميع الطلبات</Button>}{data.workflow.collectionStartedAt && !data.workflow.deliveryStartedAt && <Button onClick={() => begin('delivery')} disabled={start.isPending}><Bike size={17} /> خرج للتوصيل</Button>}{data.workflow.deliveryStartedAt && <span className="success-inline"><Check size={16} /> الخدمة بدات، الله يعاون</span>}<span className="prepared-count"><Package size={15} /> {data.preparedOrders} طلب واجد</span></div>
        {start.isError && <ErrorBox error={start.error} />}
      </section>
      <section className="metric-grid"><Metric label="مجموع الطلبات" value={data.totalOrders} icon={Package} note={`${data.awaitingOrders} باقيين`} /><Metric label="توصيلات كملات" value={data.deliveredOrders} icon={Check} note={`${data.failedOrders} ما تسلّموش`} /><Metric label="مداخيل التوصيل" value={money(data.deliveryRevenueCentimes)} icon={ArrowUpRight} note="على حسب الفترة" /><Metric label="فلوس عند التجار" value={money(data.outstandingCentimes)} icon={Wallet} note={`${data.activeMerchants} تاجر خدام`} /></section>
      <section className="content-panel"><div className="panel-heading"><div><span className="eyebrow small-eyebrow">آخر الحركة</span><h2>آخر الطلبات</h2></div><Link href="/orders" className="text-link">جميع الطلبات <ChevronLeft size={15} /></Link></div>{data.recentOrders.length ? <OrderTable orders={data.recentOrders.slice(0, 6)} /> : <Empty title="ما كاين حتى طلب" detail="الطلبات الجديدة غادي يبانوا هنا." action={<Link href="/orders/new" className="button button-secondary"><Plus size={16} /> زيد طلب</Link>} />}</section>
    </>}
  </div>;
}
function Metric({ label, value, icon: Icon, note }: { label: string; value: string | number; icon: IconType; note: string }) {
  return <div className="metric-card"><div className="metric-top"><span>{label}</span><span className="metric-icon"><Icon size={17} /></span></div><strong>{value}</strong><small>{note}</small></div>;
}
function OrderTable({ orders }: { orders: any[] }) {
  return <div className="table-wrap"><table><thead><tr><th>الطلب</th><th>الزبون</th><th>التاجر</th><th>المنطقة</th><th>الحالة</th><th>مصاريف التوصيل</th><th /></tr></thead><tbody>{orders.map((o) => <tr key={o.id} data-testid={`row-order-${o.id}`}><td><Link className="mono order-ref" href={`/orders/${o.id}`}>{o.reference}</Link><small>{dateText(o.createdAt)}</small></td><td><b>{o.customerName}</b><a className="phone-link" href={`tel:${o.customerPhone}`} dir="ltr">{o.customerPhone}</a></td><td>{o.merchantName}</td><td>{o.areaType === 'fes' ? 'فاس' : 'النواحي'}</td><td><Status value={o.status} /></td><td className="money">{money(o.deliveryFeeCentimes)}</td><td><Link href={`/orders/${o.id}`} className="row-arrow" aria-label="تفاصيل الطلب"><ChevronLeft size={17} /></Link></td></tr>)}</tbody></table></div>;
}

function OrdersPage() {
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const params = useMemo(() => ({ ...(search ? { search } : {}), ...(status ? { status: status as OrderStatus } : {}) }), [search, status]);
  const orders = useListOrders(params);
  return <div className="animate-enter"><PageTitle title="الطلبات" subtitle="قلب على الطلبات، وتبع الحالة ديال كل توصيل." action={<Link href="/orders/new" className="button button-primary"><Plus size={17} /> طلب جديد</Link>} />
    <div className="filters"><label className="searchbox"><Search size={17} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="قلب بالاسم، المرجع ولا الهاتف" data-testid="input-order-search" /></label><label className="select-filter"><Filter size={16} /><select value={status} onChange={(e) => setStatus(e.target.value)}><option value="">جميع الحالات</option>{Object.entries(statusLabels).slice(0, 6).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label></div>
    {orders.isLoading ? <Loading /> : orders.isError ? <ErrorBox error={orders.error} retry={() => orders.refetch()} /> : orders.data?.length ? <section className="content-panel"><OrderTable orders={orders.data} /></section> : <Empty title="ما لقيناش طلبات" detail={search || status ? 'بدل كلمات البحث ولا الفلتر وجرب من جديد.' : 'منين تزيد أول طلب، غادي تلقاه هنا.'} action={<Link href="/orders/new" className="button button-secondary"><Plus size={16} /> زيد طلب</Link>} />}
  </div>;
}
function OrderFormPage() {
  const [location, setLocation] = useLocation();
  const merchants = useListMerchants({ activeOnly: true });
  const settingsQuery = useGetSettings();
  const create = useCreateOrder();
  const client = useQueryClient();
  const [form, setForm] = useState({ merchantId: '', customerName: '', customerPhone: '', city: 'فاس', areaType: 'fes', deliveryAddress: '', productDescription: '', productPrice: '', collect: '', plannedDate: today(), notes: '' });
  const update = <K extends keyof typeof form>(key: K, value: (typeof form)[K]) => setForm((f) => ({ ...f, [key]: value }));
  const submit = (e: FormEvent) => { e.preventDefault(); if (!form.merchantId) return; const settings = settingsQuery.data; const input: OrderInput = { merchantId: Number(form.merchantId), customerName: form.customerName.trim(), customerPhone: form.customerPhone.trim(), city: form.city.trim(), areaType: form.areaType as 'fes' | 'surrounding', deliveryAddress: form.deliveryAddress.trim(), productDescription: form.productDescription.trim(), productPriceCentimes: form.productPrice ? Math.round(Number(form.productPrice) * 100) : null, amountToCollectCentimes: form.collect ? Math.round(Number(form.collect) * 100) : null, deliveryFeeCentimes: form.areaType === 'fes' ? (settings?.fesFeeCentimes ?? 2000) : (settings?.surroundingFeeCentimes ?? 3500), plannedDate: form.plannedDate || null, status: 'new', notes: form.notes || null }; const idempotentInput = { ...input, idempotencyKey: crypto.randomUUID() }; create.mutate({ data: idempotentInput as OrderInput }, { onSuccess: (order) => { client.invalidateQueries({ queryKey: getListOrdersQueryKey() }); client.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); client.invalidateQueries({ queryKey: getGetReportsQueryKey() }); setLocation(`/orders/${order.id}`); } }); };
  return <div className="animate-enter"><PageTitle title="طلب جديد" subtitle="دخل معلومات الزبون والتاجر باش تبدا الخدمة." action={<Link href="/orders" className="button button-quiet"><ArrowLeft size={16} /> رجوع</Link>} />
    {merchants.isLoading || settingsQuery.isLoading ? <Loading rows={3} /> : merchants.isError ? <ErrorBox error={merchants.error} retry={() => merchants.refetch()} /> : settingsQuery.isError ? <ErrorBox error={settingsQuery.error} retry={() => settingsQuery.refetch()} /> : !merchants.data?.length ? <Empty title="خاصك تاجر قبل" detail="زيد التاجر من صفحة التجار، ومن بعد رجع تسجل الطلب." action={<Link href="/merchants" className="button button-secondary"><Store size={16} /> صفحة التجار</Link>} /> :
    <form className="form-panel" onSubmit={submit}><div className="form-section-title"><span>01</span><div><b>معلومات التوصيل</b><small>فين غادي يوصل الطلب؟</small></div></div><div className="form-grid">
      <Field label="التاجر"><select required value={form.merchantId} onChange={(e) => update('merchantId', e.target.value)}><option value="">اختار التاجر</option>{merchants.data.map((m) => <option key={m.id} value={m.id}>{m.businessName}</option>)}</select></Field>
      <Field label="اسم الزبون"><input required maxLength={160} value={form.customerName} onChange={(e) => update('customerName', e.target.value)} /></Field>
      <Field label="رقم الهاتف"><input required type="tel" minLength={6} maxLength={32} dir="ltr" value={form.customerPhone} onChange={(e) => update('customerPhone', e.target.value)} /></Field>
      <Field label="المدينة"><input required value={form.city} onChange={(e) => update('city', e.target.value)} /></Field>
      <Field label="المنطقة"><select value={form.areaType} onChange={(e) => update('areaType', e.target.value)}><option value="fes">فاس</option><option value="surrounding">النواحي</option></select></Field>
      <Field label="العنوان بالتفصيل" className="span-2"><input required maxLength={500} value={form.deliveryAddress} onChange={(e) => update('deliveryAddress', e.target.value)} placeholder="الحي، الزنقة، علامة قريبة..." /></Field>
    </div><div className="form-section-title"><span>02</span><div><b>تفاصيل السلعة</b><small>الثمن والمبلغ اللي غادي يتجمع</small></div></div><div className="form-grid">
      <Field label="وصف السلعة"><input required maxLength={500} value={form.productDescription} onChange={(e) => update('productDescription', e.target.value)} /></Field><Field label="ثمن السلعة (MAD)"><input type="number" min="0" step=".01" value={form.productPrice} onChange={(e) => update('productPrice', e.target.value)} /></Field><Field label="المبلغ للتجميع (MAD)"><input type="number" min="0" step=".01" value={form.collect} onChange={(e) => update('collect', e.target.value)} /></Field><Field label="نهار التوصيل"><input type="date" value={form.plannedDate} onChange={(e) => update('plannedDate', e.target.value)} /></Field><Field label="ملاحظات" className="span-2"><textarea rows={3} maxLength={2000} value={form.notes} onChange={(e) => update('notes', e.target.value)} /></Field>
    </div><div className="form-footer">{create.isError && <ErrorBox error={create.error} />}<Button type="submit" disabled={create.isPending}><Plus size={17} /> {create.isPending ? 'كنسجلو...' : 'سجل الطلب'}</Button></div></form>}</div>;
}

function OrderDetailPage() {
  const { id = '' } = useParams<{ id: string }>(); const orderId = Number(id);
  const query = useGetOrder(orderId, { query: { enabled: Number.isFinite(orderId), queryKey: getGetOrderQueryKey(orderId) } });
  const update = useUpdateOrder(); const archive = useArchiveOrder(); const client = useQueryClient(); const [, setLocation] = useLocation();
  const [editing, setEditing] = useState(false);
  const order = query.data;
  const changeStatus = (status: OrderStatus) => { if (!order || !window.confirm(`تبدل حالة الطلب لـ «${statusLabels[status]}»؟`)) return; update.mutate({ id: order.id, data: { status } }, { onSuccess: () => { client.invalidateQueries({ queryKey: getGetOrderQueryKey(order.id) }); client.invalidateQueries({ queryKey: getListOrdersQueryKey() }); client.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); client.invalidateQueries({ queryKey: getGetReportsQueryKey() }); } }); };
  const archiveIt = () => { if (!order || !window.confirm('تأكد بلي بغيتي تأرشف هاد الطلب؟')) return; archive.mutate({ id: order.id }, { onSuccess: () => { client.invalidateQueries({ queryKey: getListOrdersQueryKey() }); client.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); client.invalidateQueries({ queryKey: getGetReportsQueryKey() }); setLocation('/orders'); } }); };
  return <div className="animate-enter"><PageTitle title="تفاصيل الطلب" subtitle="المعلومات والحالة ديال التوصيل." action={<Link href="/orders" className="button button-quiet"><ArrowLeft size={16} /> الطلبات</Link>} />
    {query.isLoading ? <Loading rows={5} /> : query.isError ? <ErrorBox error={query.error} retry={() => query.refetch()} /> : order && <><section className="detail-hero"><div><span className="eyebrow small-eyebrow">مرجع الطلب</span><h2 className="mono">{order.reference}</h2><span className="detail-date">{dateText(order.createdAt)}</span></div><Status value={order.status} /></section>
      <div className="detail-layout"><section className="content-panel"><div className="panel-heading"><div><span className="eyebrow small-eyebrow">معلومات الطلب</span><h2>{order.customerName}</h2></div><a className="button button-secondary" href={`tel:${order.customerPhone}`}>اتصال بالزبون</a></div><div className="detail-list"><Detail label="التاجر" value={<Link href={`/merchants/${order.merchantId}`} className="text-link">{order.merchantName}</Link>} /><Detail label="رقم الزبون" value={<a href={`tel:${order.customerPhone}`} dir="ltr">{order.customerPhone}</a>} /><Detail label="المدينة والمنطقة" value={`${order.city} · ${order.areaType === 'fes' ? 'فاس' : 'النواحي'}`} /><Detail label="العنوان" value={order.deliveryAddress} /><Detail label="السلعة" value={order.productDescription} /><Detail label="ثمن السلعة" value={money(order.productPriceCentimes)} /><Detail label="المبلغ للتجميع" value={money(order.amountToCollectCentimes)} /><Detail label="مصاريف التوصيل" value={money(order.deliveryFeeCentimes)} />{order.notes && <Detail label="ملاحظات" value={order.notes} />}</div></section>
      <section className="content-panel"><div className="panel-heading"><div><span className="eyebrow small-eyebrow">تسيير الطلب</span><h2>بدل الحالة</h2></div></div><Field label="الحالة الجديدة"><select value={order.status} onChange={(e) => changeStatus(e.target.value as OrderStatus)} disabled={update.isPending}>{Object.entries(statusLabels).slice(0, 6).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></Field>{update.isError && <ErrorBox error={update.error} />}<div className="action-stack"><p className="muted-copy">كل تبديل كيتسجل فالسجل ديال الطلب.</p><Button variant="secondary" onClick={() => setEditing(!editing)}>{editing ? 'سد التعديل' : 'تعديل التفاصيل'}</Button><Button variant="danger" onClick={archiveIt} disabled={archive.isPending}><X size={16} /> أرشف الطلب</Button>{archive.isError && <ErrorBox error={archive.error} />}</div>{editing && <OrderEditor order={order} onDone={() => { setEditing(false); query.refetch(); }} />}{order.statusHistory?.length > 0 && <div className="history"><h3>تاريخ الحالات</h3>{order.statusHistory.map((h, i) => <div className="history-row" key={`${h.changedAt}-${i}`}><span className="history-dot" /><div><Status value={h.newStatus} /><small>{dateText(h.changedAt)}{h.notes ? ` · ${h.notes}` : ''}</small></div></div>)}</div>}</section></div></>}
  </div>;
}
function OrderEditor({ order, onDone }: { order: any; onDone: () => void }) {
  const update = useUpdateOrder(); const client = useQueryClient(); const merchants = useListMerchants();
  const [form, setForm] = useState({ merchantId: String(order.merchantId), customerName: order.customerName, customerPhone: order.customerPhone, city: order.city, areaType: order.areaType, deliveryAddress: order.deliveryAddress, productDescription: order.productDescription, productPrice: order.productPriceCentimes == null ? '' : String(order.productPriceCentimes / 100), collect: order.amountToCollectCentimes == null ? '' : String(order.amountToCollectCentimes / 100), deliveryFee: String(order.deliveryFeeCentimes / 100), plannedDate: order.plannedDate?.slice(0, 10) || '', notes: order.notes || '' });
  const edit = <K extends keyof typeof form>(key: K, value: (typeof form)[K]) => setForm((f) => ({ ...f, [key]: value }));
  const submit = (e: FormEvent) => { e.preventDefault(); const data = { merchantId: Number(form.merchantId), customerName: form.customerName.trim(), customerPhone: form.customerPhone.trim(), city: form.city.trim(), areaType: form.areaType as 'fes' | 'surrounding', deliveryAddress: form.deliveryAddress.trim(), productDescription: form.productDescription.trim(), productPriceCentimes: form.productPrice ? Math.round(Number(form.productPrice) * 100) : null, amountToCollectCentimes: form.collect ? Math.round(Number(form.collect) * 100) : null, deliveryFeeCentimes: Math.round(Number(form.deliveryFee) * 100), plannedDate: form.plannedDate || null, notes: form.notes || null }; update.mutate({ id: order.id, data }, { onSuccess: () => { client.invalidateQueries({ queryKey: getGetOrderQueryKey(order.id) }); client.invalidateQueries({ queryKey: getListOrdersQueryKey() }); client.invalidateQueries({ queryKey: getGetDashboardQueryKey() }); client.invalidateQueries({ queryKey: getGetReportsQueryKey() }); onDone(); } }); };
  return <form className="edit-order-form" onSubmit={submit}><div className="form-grid"><Field label="التاجر"><select required value={form.merchantId} onChange={(e) => edit('merchantId', e.target.value)}>{merchants.data?.map((m) => <option key={m.id} value={m.id}>{m.businessName}</option>)}</select></Field><Field label="الزبون"><input required value={form.customerName} onChange={(e) => edit('customerName', e.target.value)} /></Field><Field label="الهاتف"><input required type="tel" dir="ltr" value={form.customerPhone} onChange={(e) => edit('customerPhone', e.target.value)} /></Field><Field label="المدينة"><input required value={form.city} onChange={(e) => edit('city', e.target.value)} /></Field><Field label="المنطقة"><select value={form.areaType} onChange={(e) => edit('areaType', e.target.value)}><option value="fes">فاس</option><option value="surrounding">النواحي</option></select></Field><Field label="العنوان"><input required value={form.deliveryAddress} onChange={(e) => edit('deliveryAddress', e.target.value)} /></Field><Field label="السلعة"><input required value={form.productDescription} onChange={(e) => edit('productDescription', e.target.value)} /></Field><Field label="ثمن السلعة (MAD)"><input type="number" min="0" step=".01" value={form.productPrice} onChange={(e) => edit('productPrice', e.target.value)} /></Field><Field label="المبلغ للتجميع (MAD)"><input type="number" min="0" step=".01" value={form.collect} onChange={(e) => edit('collect', e.target.value)} /></Field><Field label="مصاريف التوصيل (MAD)"><input required type="number" min="0" step=".01" value={form.deliveryFee} onChange={(e) => edit('deliveryFee', e.target.value)} /></Field><Field label="نهار التوصيل"><input type="date" value={form.plannedDate} onChange={(e) => edit('plannedDate', e.target.value)} /></Field><Field label="ملاحظات"><input value={form.notes} onChange={(e) => edit('notes', e.target.value)} /></Field></div>{update.isError && <ErrorBox error={update.error} />}<div className="form-footer"><Button type="submit" disabled={update.isPending}><Check size={16} /> حفظ التعديلات</Button></div></form>;
}
function Detail({ label, value }: { label: string; value: ReactNode }) { return <div className="detail-row"><span>{label}</span><b>{value}</b></div>; }

function MerchantsPage() {
  const [search, setSearch] = useState(''); const [adding, setAdding] = useState(false);
  const query = useListMerchants({ ...(search ? { search } : {}) }); const create = useCreateMerchant(); const client = useQueryClient();
  const [form, setForm] = useState<MerchantInput>({ businessName: '', contactName: '', phone: '', address: null, notes: null });
  const submit = (e: FormEvent) => { e.preventDefault(); create.mutate({ data: form }, { onSuccess: () => { client.invalidateQueries({ queryKey: getListMerchantsQueryKey() }); setAdding(false); setForm({ businessName: '', contactName: '', phone: '', address: null, notes: null }); } }); };
  return <div className="animate-enter"><PageTitle title="التجار" subtitle="دليل التجار والحسابات ديالهم." action={<Button onClick={() => setAdding(!adding)}><Plus size={17} /> تاجر جديد</Button>} />
    {adding && <form className="form-panel compact-form" onSubmit={submit}><div className="panel-heading"><div><span className="eyebrow small-eyebrow">تسجيل تاجر</span><h2>معلومات النشاط</h2></div><button type="button" className="icon-button" onClick={() => setAdding(false)} aria-label="إغلاق"><X size={18} /></button></div><div className="form-grid"><Field label="اسم النشاط"><input required value={form.businessName} onChange={(e) => setForm({ ...form, businessName: e.target.value })} /></Field><Field label="اسم المسؤول"><input required value={form.contactName} onChange={(e) => setForm({ ...form, contactName: e.target.value })} /></Field><Field label="الهاتف"><input required type="tel" dir="ltr" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field><Field label="العنوان"><input value={form.address || ''} onChange={(e) => setForm({ ...form, address: e.target.value || null })} /></Field></div>{create.isError && <ErrorBox error={create.error} />}<div className="form-footer"><Button type="submit" disabled={create.isPending}><Check size={16} /> حفظ التاجر</Button></div></form>}
    <label className="searchbox wide-search"><Search size={17} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="قلب على اسم التاجر ولا الهاتف" /></label>
    {query.isLoading ? <Loading /> : query.isError ? <ErrorBox error={query.error} retry={() => query.refetch()} /> : query.data?.length ? <div className="merchant-grid">{query.data.map((m) => <Link href={`/merchants/${m.id}`} className="merchant-card" key={m.id}><div className="merchant-card-top"><span className="merchant-mark">{m.businessName.slice(0, 1)}</span><span className={`merchant-active ${m.isActive ? '' : 'inactive'}`}>{m.isActive ? 'خدام' : 'موقوف'}</span></div><h2>{m.businessName}</h2><p>{m.contactName}</p><span className="merchant-phone" dir="ltr">{m.phone}</span><div className="merchant-stats"><span><small>طلبات تسلمات</small><b>{m.deliveredCount}</b></span><span><small>باقي للحساب</small><b>{money(m.outstandingCentimes)}</b></span></div><div className="merchant-card-bottom"><span>فتح الدفتر</span><ChevronLeft size={16} /></div></Link>)}</div> : <Empty title="ما كاينينش تجار" detail="زيد التجار اللي كتخدم معاهم باش تربطهم بالطلبات." action={<Button variant="secondary" onClick={() => setAdding(true)}><Plus size={16} /> زيد تاجر</Button>} />}
  </div>;
}
function MerchantPage() {
  const { id = '' } = useParams<{ id: string }>(); const merchantId = Number(id);
  const merchant = useGetMerchant(merchantId, { query: { enabled: !!merchantId, queryKey: getGetMerchantQueryKey(merchantId) } });
  const summary = useGetMerchantSummary(merchantId, { query: { enabled: !!merchantId, queryKey: getGetMerchantSummaryQueryKey(merchantId) } });
  const paymentList = useListPayments({ merchantId });
  const update = useUpdateMerchant(); const client = useQueryClient(); const [editing, setEditing] = useState(false);
  const m = merchant.data;
  return <div className="animate-enter"><PageTitle title="دفتر التاجر" subtitle="الطلبات، مصاريف التوصيل والدفعات." action={<Link href="/merchants" className="button button-quiet"><ArrowLeft size={16} /> التجار</Link>} />
    {merchant.isLoading ? <Loading rows={5} /> : merchant.isError ? <ErrorBox error={merchant.error} retry={() => merchant.refetch()} /> : m && <><section className="merchant-profile"><span className="merchant-mark large">{m.businessName.slice(0, 1)}</span><div className="merchant-profile-copy"><span className="eyebrow small-eyebrow">تاجر من {dateText(m.createdAt)}</span><h2>{m.businessName}</h2><p>{m.contactName} · <a href={`tel:${m.phone}`} dir="ltr">{m.phone}</a></p></div><div className="merchant-contact-actions"><a className="button button-secondary" href={`https://wa.me/${m.phone.replace(/\D/g, '')}`} target="_blank" rel="noreferrer">واتساب</a><Button variant="secondary" onClick={() => setEditing(!editing)}>{editing ? 'سد التعديل' : 'تعديل المعلومات'}</Button></div></section>
      {editing && <MerchantEdit merchant={m} onDone={() => { setEditing(false); client.invalidateQueries({ queryKey: getGetMerchantQueryKey(m.id) }); client.invalidateQueries({ queryKey: getListMerchantsQueryKey() }); }} />}
      <section className="metric-grid merchant-metrics"><Metric label="توصيلات تسلمات" value={summary.data?.deliveredCount ?? m.deliveredCount} icon={Check} note="المجموع" /><Metric label="مصاريف التوصيل" value={money(summary.data?.totalFeesCentimes ?? m.totalFeesCentimes)} icon={ArrowUpRight} note="المجموع" /><Metric label="الدفعات" value={money(summary.data?.totalPaymentsCentimes ?? m.totalPaymentsCentimes)} icon={ArrowDownLeft} note="مؤكدة" /><Metric label="باقي للحساب" value={money(summary.data?.outstandingCentimes ?? m.outstandingCentimes)} icon={Wallet} note="الرصيد الحالي" /></section>
      {summary.isError && <ErrorBox error={summary.error} retry={() => summary.refetch()} />}
      <section className="content-panel"><div className="panel-heading"><div><span className="eyebrow small-eyebrow">حركة التوصيل</span><h2>طلبات التاجر</h2></div><Link href={`/payments/new?merchantId=${m.id}`} className="button button-primary"><Plus size={16} /> سجل دفعة</Link></div>{m.orders.length ? <OrderTable orders={m.orders} /> : <Empty title="ما كايناش طلبات" detail="الطلبات ديال هاد التاجر غادي يبانوا هنا." />}</section>
      <section className="content-panel"><div className="panel-heading"><div><span className="eyebrow small-eyebrow">دفتر الأداءات</span><h2>الدفعات</h2></div></div>{paymentList.isLoading ? <Loading rows={2} /> : paymentList.isError ? <ErrorBox error={paymentList.error} retry={() => paymentList.refetch()} /> : paymentList.data?.length ? <div className="table-wrap"><table><thead><tr><th>المرجع</th><th>التاريخ</th><th>الطريقة</th><th>الحالة</th><th>المبلغ</th><th /></tr></thead><tbody>{paymentList.data.map((p) => <tr key={p.id}><td className="mono">{p.reference}</td><td>{dateText(p.paymentDate)}</td><td>{p.method === 'cash' ? 'نقدا' : p.method === 'bank_transfer' ? 'تحويل بنكي' : 'أخرى'}</td><td><Status value={p.status} /></td><td className="money">{money(p.amountCentimes)}</td><td>{p.status === 'confirmed' && <ReversePayment id={p.id} merchantId={m.id} />}</td></tr>)}</tbody></table></div> : <Empty title="ما تسجلات حتى دفعة" detail="سجل الأداءات باش يبقى الحساب واضح." />}</section></>}
  </div>;
}
function MerchantEdit({ merchant, onDone }: { merchant: any; onDone: () => void }) {
  const update = useUpdateMerchant(); const client = useQueryClient(); const [name, setName] = useState(merchant.businessName); const [contact, setContact] = useState(merchant.contactName); const [phone, setPhone] = useState(merchant.phone); const [address, setAddress] = useState(merchant.address || '');
  const submit = (e: FormEvent) => { e.preventDefault(); update.mutate({ id: merchant.id, data: { businessName: name, contactName: contact, phone, address: address || null } }, { onSuccess: () => { client.invalidateQueries({ queryKey: getGetMerchantQueryKey(merchant.id) }); client.invalidateQueries({ queryKey: getListMerchantsQueryKey() }); onDone(); } }); };
  return <form className="form-panel compact-form" onSubmit={submit}><div className="form-grid"><Field label="اسم النشاط"><input required value={name} onChange={(e) => setName(e.target.value)} /></Field><Field label="المسؤول"><input required value={contact} onChange={(e) => setContact(e.target.value)} /></Field><Field label="الهاتف"><input required dir="ltr" value={phone} onChange={(e) => setPhone(e.target.value)} /></Field><Field label="العنوان"><input value={address} onChange={(e) => setAddress(e.target.value)} /></Field></div>{update.isError && <ErrorBox error={update.error} />}<div className="form-footer"><Button type="submit" disabled={update.isPending}><Check size={16} /> حفظ التعديلات</Button></div></form>;
}
function ReversePayment({ id, merchantId }: { id: number; merchantId: number }) {
  const reverse = useReversePayment(); const client = useQueryClient();
  const act = () => { const reason = window.prompt('علاش بغيتي ترجع هاد الدفعة؟'); if (!reason?.trim()) return; reverse.mutate({ id, data: { reason } }, { onSuccess: () => { client.invalidateQueries({ queryKey: getGetMerchantQueryKey(merchantId) }); client.invalidateQueries({ queryKey: getGetMerchantSummaryQueryKey(merchantId) }); client.invalidateQueries({ queryKey: getListPaymentsQueryKey() }); client.invalidateQueries({ queryKey: getListMerchantsQueryKey() }); client.invalidateQueries({ queryKey: getGetReportsQueryKey() }); } }); };
  return <button className="link-danger" onClick={act} disabled={reverse.isPending}>رجّع</button>;
}

function PaymentFormPage() {
  const [, setLocation] = useLocation(); const [params] = useState(() => new URLSearchParams(window.location.search));
  const merchants = useListMerchants({ activeOnly: true }); const create = useCreatePayment(); const client = useQueryClient();
  const [form, setForm] = useState({ merchantId: params.get('merchantId') || '', amount: '', date: today(), method: 'cash', reference: '', notes: '', overpay: false });
  const submit = (e: FormEvent) => { e.preventDefault(); const data: PaymentInput = { merchantId: Number(form.merchantId), amountCentimes: Math.round(Number(form.amount) * 100), paymentDate: form.date, method: form.method as PaymentInput['method'], transactionReference: form.reference || null, notes: form.notes || null, idempotencyKey: crypto.randomUUID(), confirmOverpayment: form.overpay }; create.mutate({ data }, { onSuccess: (p) => { client.invalidateQueries({ queryKey: getListPaymentsQueryKey() }); client.invalidateQueries({ queryKey: getGetMerchantQueryKey(p.merchantId) }); client.invalidateQueries({ queryKey: getGetMerchantSummaryQueryKey(p.merchantId) }); client.invalidateQueries({ queryKey: getListMerchantsQueryKey() }); client.invalidateQueries({ queryKey: getGetReportsQueryKey() }); setLocation(`/merchants/${p.merchantId}`); } }); };
  return <div className="animate-enter"><PageTitle title="تسجيل دفعة" subtitle="سجل أداء التاجر وخلي الحساب ديما واضح." action={<Link href="/merchants" className="button button-quiet"><ArrowLeft size={16} /> رجوع</Link>} />
    {merchants.isLoading ? <Loading rows={3} /> : merchants.isError ? <ErrorBox error={merchants.error} retry={() => merchants.refetch()} /> : <form className="form-panel narrow-form" onSubmit={submit}><div className="form-grid"><Field label="التاجر"><select required value={form.merchantId} onChange={(e) => setForm({ ...form, merchantId: e.target.value })}><option value="">اختار التاجر</option>{merchants.data?.map((m) => <option key={m.id} value={m.id}>{m.businessName} · باقي {money(m.outstandingCentimes)}</option>)}</select></Field><Field label="المبلغ (MAD)"><input required type="number" min=".01" step=".01" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} /></Field><Field label="تاريخ الدفعة"><input required type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></Field><Field label="طريقة الأداء"><select value={form.method} onChange={(e) => setForm({ ...form, method: e.target.value })}><option value="cash">نقدا</option><option value="bank_transfer">تحويل بنكي</option><option value="other">أخرى</option></select></Field><Field label="مرجع المعاملة"><input value={form.reference} onChange={(e) => setForm({ ...form, reference: e.target.value })} /></Field><Field label="ملاحظات"><input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field></div><label className="checkline"><input type="checkbox" checked={form.overpay} onChange={(e) => setForm({ ...form, overpay: e.target.checked })} /> كنأكد تسجيل مبلغ أكبر من الرصيد إلا كان</label>{create.isError && <ErrorBox error={create.error} />}<div className="form-footer"><Button type="submit" disabled={create.isPending}><Check size={17} /> {create.isPending ? 'كنسجلو...' : 'أكد الدفعة'}</Button></div></form>}
  </div>;
}

function AccountingPage() {
  const [from, setFrom] = useState(today().slice(0, 8) + '01'); const [to, setTo] = useState(today());
  const params = useMemo(() => ({ from, to }), [from, to]);
  const report = useGetReports(params);
  const csv = useExportReportCsv(params, { query: { enabled: false, queryKey: getExportReportCsvQueryKey(params) } });
  const exportCsv = async () => { const res = await csv.refetch(); if (!res.data) return; const blob = new Blob([res.data], { type: 'text/csv;charset=utf-8' }); const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `premium-livreson-${from}-${to}.csv`; a.click(); URL.revokeObjectURL(url); };
  const r = report.data;
  return <div className="animate-enter"><PageTitle title="الحسابات" subtitle="ملخص الخدمة والفلوس خلال الفترة اللي تختار." action={<Button variant="secondary" onClick={exportCsv} disabled={csv.isFetching}><Download size={16} /> {csv.isFetching ? 'كنوجد الملف...' : 'صدّر CSV'}</Button>} />
    <div className="date-range"><span><CalendarDays size={16} /> الفترة</span><input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /><span>حتى</span><input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></div>
    {csv.isError && <ErrorBox error={csv.error} />}
    {report.isLoading ? <Loading rows={5} /> : report.isError ? <ErrorBox error={report.error} retry={() => report.refetch()} /> : r && <>
      <section className="metric-grid"><Metric label="توصيلات تسلمات" value={r.completedDeliveries} icon={Check} note={`${dateText(r.from)} – ${dateText(r.to)}`} /><Metric label="مداخيل التوصيل" value={money(r.deliveryRevenueCentimes)} icon={ArrowUpRight} note="المجموع" /><Metric label="دفعات التجار" value={money(r.merchantPaymentsCentimes)} icon={ArrowDownLeft} note="المجموع" /><Metric label="باقي للحساب" value={money(r.outstandingCentimes)} icon={Wallet} note="الرصيد الحالي" /></section>
      <div className="report-grid"><section className="content-panel"><div className="panel-heading"><div><span className="eyebrow small-eyebrow">حسب الحالة</span><h2>الطلبات</h2></div><FileText size={18} className="muted-icon" /></div>{r.ordersByStatus.length ? r.ordersByStatus.map((s) => <div className="report-row" key={s.status}><Status value={s.status} /><div className="report-bar"><i style={{ width: `${Math.max(5, s.count / Math.max(1, r.ordersByStatus.reduce((sum, item) => sum + item.count, 0)) * 100)}%` }} /></div><b>{s.count}</b></div>) : <Empty title="ما كايناش بيانات" detail="اختار فترة فيها طلبات." />}</section>
        <section className="content-panel"><div className="panel-heading"><div><span className="eyebrow small-eyebrow">حسب المنطقة</span><h2>مصاريف التوصيل</h2></div><MapPin size={18} className="muted-icon" /></div>{r.revenueByArea.length ? r.revenueByArea.map((a) => <div className="area-report" key={a.areaType}><div className="area-icon"><MapPin size={17} /></div><div><b>{a.areaType === 'fes' ? 'داخل فاس' : 'النواحي'}</b><small>{a.count} توصيلات</small></div><strong>{money(a.revenueCentimes)}</strong></div>) : <Empty title="ما كايناش بيانات" detail="مصاريف التوصيل غادي تبان هنا." />}</section></div>
      <section className="content-panel"><div className="panel-heading"><div><span className="eyebrow small-eyebrow">النشاط التجاري</span><h2>حسب التاجر</h2></div></div>{r.revenueByMerchant.length ? <div className="table-wrap"><table><thead><tr><th>التاجر</th><th>عدد الطلبات</th><th>مداخيل التوصيل</th></tr></thead><tbody>{r.revenueByMerchant.map((m) => <tr key={m.merchantId}><td><Link className="text-link" href={`/merchants/${m.merchantId}`}>{m.merchantName}</Link></td><td>{m.count}</td><td className="money">{money(m.revenueCentimes)}</td></tr>)}</tbody></table></div> : <Empty title="ما كايناش بيانات" detail="بيانات التجار غادي تبان هنا من بعد." />}</section>
    </>}
  </div>;
}

function SettingsPage() {
  const settings = useGetSettings(); const update = useUpdateSettings(); const { signOut } = useClerk(); const client = useQueryClient();
  const [form, setForm] = useState<SettingsInput | null>(null); const [saved, setSaved] = useState(false);
  useEffect(() => { if (settings.data) setForm({ businessName: settings.data.businessName, phone: settings.data.phone, fesFeeCentimes: settings.data.fesFeeCentimes, surroundingFeeCentimes: settings.data.surroundingFeeCentimes, collectionStart: settings.data.collectionStart, collectionEnd: settings.data.collectionEnd, currency: 'MAD', timezone: settings.data.timezone }); }, [settings.data]);
  const submit = (e: FormEvent) => { e.preventDefault(); if (!form) return; update.mutate({ data: form }, { onSuccess: () => { client.invalidateQueries({ queryKey: getGetSettingsQueryKey() }); setSaved(true); setTimeout(() => setSaved(false), 3000); } }); };
  return <div className="animate-enter"><PageTitle title="الإعدادات" subtitle="ضبط معلومات النشاط ومصاريف الخدمة." />
    {settings.isLoading ? <Loading rows={4} /> : settings.isError ? <ErrorBox error={settings.error} retry={() => settings.refetch()} /> : form && <form className="form-panel settings-form" onSubmit={submit}><div className="form-section-title"><span>01</span><div><b>معلومات النشاط</b><small>كتبان فحسابك الداخلي</small></div></div><div className="form-grid"><Field label="اسم النشاط"><input required value={form.businessName} onChange={(e) => setForm({ ...form, businessName: e.target.value })} /></Field><Field label="رقم الهاتف"><input required type="tel" dir="ltr" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></Field></div>
      <div className="form-section-title"><span>02</span><div><b>مصاريف التوصيل</b><small>بالدرهم المغربي</small></div></div><div className="form-grid"><Field label="داخل فاس (MAD)"><input required type="number" min="0" step=".01" value={(form.fesFeeCentimes / 100).toFixed(2)} onChange={(e) => setForm({ ...form, fesFeeCentimes: Math.round(Number(e.target.value) * 100) })} /></Field><Field label="النواحي (MAD)"><input required type="number" min="0" step=".01" value={(form.surroundingFeeCentimes / 100).toFixed(2)} onChange={(e) => setForm({ ...form, surroundingFeeCentimes: Math.round(Number(e.target.value) * 100) })} /></Field></div>
      <div className="form-section-title"><span>03</span><div><b>وقت التجميع</b><small>النافذة اليومية لاستقبال الطلبات</small></div></div><div className="form-grid"><Field label="من"><input required type="time" value={form.collectionStart} onChange={(e) => setForm({ ...form, collectionStart: e.target.value })} /></Field><Field label="حتى"><input required type="time" value={form.collectionEnd} onChange={(e) => setForm({ ...form, collectionEnd: e.target.value })} /></Field></div>
      {saved && <div className="notice success-notice"><Check size={17} /> تحفضات التغييرات</div>}{update.isError && <ErrorBox error={update.error} />}<div className="form-footer"><Button type="submit" disabled={update.isPending}><Check size={16} /> {update.isPending ? 'كنحفظو...' : 'حفظ الإعدادات'}</Button></div></form>}
    <section className="logout-panel"><div><span className="eyebrow small-eyebrow">جلسة المالك</span><h2>باغي تخرج من الحساب؟</h2><p>تقدر ترجع تدخل بأي وقت من صفحة الدخول.</p></div><Button variant="danger" onClick={() => signOut({ redirectUrl: basePath || '/' })}><LogOut size={17} /> خروج آمن</Button></section>
  </div>;
}

function NotFound() { return <div className="not-found" dir="rtl"><span className="eyebrow small-eyebrow">404 · ما لقيناش هاد الصفحة</span><h1>الطريق سالا هنا.</h1><Link href="/dashboard" className="button button-primary"><Home size={17} /> رجع للرئيسية</Link></div>; }
function ProtectedPage({ children }: { children: ReactNode }) { return <Guard>{children}</Guard>; }
function RouterContent() {
  const [, setLocation] = useLocation();
  return <ClerkProvider publishableKey={clerkPubKey} proxyUrl={clerkProxyUrl} appearance={appearance} signInUrl={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} localization={{ signIn: { start: { title: 'مرحبا بعودتك', subtitle: 'دخل باش توصل لحساب الخدمة ديالك' } } }} routerPush={(to) => setLocation(stripBase(to))} routerReplace={(to) => setLocation(stripBase(to), { replace: true })}>
    <QueryClientProvider client={queryClient}><ClerkCacheInvalidator /><Switch>
      <Route path="/" component={HomeRoute} />
      <Route path="/sign-in/*?" component={SignInPage} />
      <Route path="/sign-up/*?" component={InvitationSignUpPage} />
      <Route path="/dashboard"><ProtectedPage><DashboardPage /></ProtectedPage></Route>
      <Route path="/orders"><ProtectedPage><OrdersPage /></ProtectedPage></Route>
      <Route path="/orders/new"><ProtectedPage><OrderFormPage /></ProtectedPage></Route>
      <Route path="/orders/:id"><ProtectedPage><OrderDetailPage /></ProtectedPage></Route>
      <Route path="/merchants"><ProtectedPage><MerchantsPage /></ProtectedPage></Route>
      <Route path="/merchants/:id"><ProtectedPage><MerchantPage /></ProtectedPage></Route>
      <Route path="/payments/new"><ProtectedPage><PaymentFormPage /></ProtectedPage></Route>
      <Route path="/accounting"><ProtectedPage><AccountingPage /></ProtectedPage></Route>
      <Route path="/settings"><ProtectedPage><SettingsPage /></ProtectedPage></Route>
      <Route component={NotFound} />
    </Switch></QueryClientProvider>
  </ClerkProvider>;
}
function App() {
  if (!clerkPubKey) return <div className="auth-config-error" dir="rtl">خاص إعداد مفتاح الدخول باش نخدمو هاد الخدمة.</div>;
  return <WouterRouter base={basePath}><RouterContent /></WouterRouter>;
}
export default App;
