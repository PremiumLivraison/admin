import { clerkClient } from "@clerk/express";

const emailAddress = process.env.OWNER_EMAIL?.trim().toLowerCase();
if (!emailAddress) {
  console.error("OWNER_EMAIL is not configured.");
  process.exit(1);
}
if (!process.env.CLERK_SECRET_KEY) {
  console.error("Clerk is not configured for this environment.");
  process.exit(1);
}

try {
  const users = await clerkClient.users.getUserList({
    emailAddress: [emailAddress],
    limit: 1,
  });
  if (users.data.length > 0) {
    console.log("The configured owner account already exists.");
    process.exit(0);
  }

  const invitations = await clerkClient.invitations.getInvitationList({
    query: emailAddress,
  });
  const activeInvitation = invitations.data.find(
    (invitation) =>
      invitation.emailAddress.toLowerCase() === emailAddress &&
      invitation.status === "pending",
  );
  if (activeInvitation) {
    console.log("An owner invitation is already pending.");
    process.exit(0);
  }

  await clerkClient.invitations.createInvitation({
    emailAddress,
    publicMetadata: { role: "owner" },
    notify: true,
  });
  console.log("Owner invitation sent.");
} catch {
  console.error("Could not send the owner invitation. Check the Clerk setup and try again.");
  process.exitCode = 1;
}
