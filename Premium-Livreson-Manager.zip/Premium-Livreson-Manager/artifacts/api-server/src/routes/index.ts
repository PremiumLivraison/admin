import { Router, type IRouter } from "express";
import healthRouter from "./health";
import ordersRouter from "./orders";
import merchantsRouter from "./merchants";
import accountingRouter from "./accounting";
import { requireOwner } from "../middlewares/requireOwner";

const router: IRouter = Router();
const ownerRouter: IRouter = Router();

router.use(healthRouter);
ownerRouter.use(requireOwner);
ownerRouter.use(ordersRouter);
ownerRouter.use(merchantsRouter);
ownerRouter.use(accountingRouter);
router.use(ownerRouter);

export default router;
