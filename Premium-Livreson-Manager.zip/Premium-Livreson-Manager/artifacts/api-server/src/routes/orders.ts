import {
  and,
  desc,
  eq,
  gte,
  ilike,
  isNull,
  lt,
  or,
} from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  ArchiveOrderParams,
  CreateOrderBody,
  CreateOrderResponse,
  GetOrderParams,
  GetOrderResponse,
  ListOrdersQueryParams,
  ListOrdersResponse,
  UpdateOrderBody,
  UpdateOrderParams,
  UpdateOrderResponse,
} from "@workspace/api-zod";
import {
  db,
  merchantsTable,
  orderStatusHistoryTable,
  ordersTable,
} from "@workspace/db";
import {
  createReference,
  getDateBounds,
  toCalendarDate,
  toOrderDto,
  toStatusHistoryDto,
} from "../lib/livreson";

const router: IRouter = Router();

router.get("/orders", async (req, res): Promise<void> => {
  const query = ListOrdersQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const filters = [isNull(ordersTable.deletedAt)];
  const search = query.data.search?.trim();
  if (search) {
    filters.push(
      or(
        ilike(ordersTable.customerName, `%${search}%`),
        ilike(ordersTable.customerPhone, `%${search}%`),
        ilike(ordersTable.reference, `%${search}%`),
      )!,
    );
  }
  if (query.data.merchantId) {
    filters.push(eq(ordersTable.merchantId, query.data.merchantId));
  }
  if (query.data.areaType) {
    filters.push(eq(ordersTable.areaType, query.data.areaType));
  }
  if (query.data.status) {
    filters.push(eq(ordersTable.status, query.data.status));
  }
  if (query.data.from || query.data.to) {
    const fromValue = query.data.from ?? query.data.to!;
    const toValue = query.data.to ?? query.data.from!;
    const from = toCalendarDate(fromValue);
    const to = toCalendarDate(toValue);
    const bounds = getDateBounds(from, to);
    filters.push(gte(ordersTable.createdAt, bounds.start));
    filters.push(lt(ordersTable.createdAt, bounds.endExclusive));
  }

  const rows = await db
    .select({ order: ordersTable, merchantName: merchantsTable.businessName })
    .from(ordersTable)
    .innerJoin(merchantsTable, eq(ordersTable.merchantId, merchantsTable.id))
    .where(and(...filters))
    .orderBy(desc(ordersTable.createdAt))
    .limit(300);
  res.json(
    ListOrdersResponse.parse(
      rows.map(({ order, merchantName }) => toOrderDto(order, merchantName)),
    ),
  );
});

router.post("/orders", async (req, res): Promise<void> => {
  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const result = await db.transaction(async (tx) => {
    const [existing] = await tx
      .select()
      .from(ordersTable)
      .where(eq(ordersTable.idempotencyKey, parsed.data.idempotencyKey));
    if (existing?.deletedAt) {
      return { archived: true as const };
    }
    if (existing) {
      const [merchant] = await tx
        .select({ businessName: merchantsTable.businessName })
        .from(merchantsTable)
        .where(eq(merchantsTable.id, existing.merchantId));
      return {
        order: toOrderDto(existing, merchant?.businessName ?? ""),
        duplicate: true,
      };
    }
    const [merchant] = await tx
      .select()
      .from(merchantsTable)
      .where(eq(merchantsTable.id, parsed.data.merchantId));
    if (!merchant || !merchant.isActive) return null;

    const now = new Date();
    const [created] = await tx
      .insert(ordersTable)
      .values({
        ...parsed.data,
        reference: createReference("PL-O"),
        plannedDate:
          parsed.data.plannedDate === null
            ? null
            : parsed.data.plannedDate
              ? toCalendarDate(parsed.data.plannedDate)
              : null,
        deliveredAt: parsed.data.status === "delivered" ? now : null,
      })
      .onConflictDoNothing({ target: ordersTable.idempotencyKey })
      .returning();
    if (!created) {
      const [repeated] = await tx
        .select()
        .from(ordersTable)
        .where(eq(ordersTable.idempotencyKey, parsed.data.idempotencyKey));
      if (!repeated) throw new Error("Order could not be created");
      if (repeated.deletedAt) return { archived: true as const };
      const [repeatedMerchant] = await tx
        .select({ businessName: merchantsTable.businessName })
        .from(merchantsTable)
        .where(eq(merchantsTable.id, repeated.merchantId));
      return {
        order: toOrderDto(repeated, repeatedMerchant?.businessName ?? ""),
        duplicate: true,
      };
    }

    await tx.insert(orderStatusHistoryTable).values({
      orderId: created.id,
      previousStatus: null,
      newStatus: created.status,
      changedAt: now,
    });
    return {
      order: toOrderDto(created, merchant.businessName),
      duplicate: false,
    };
  });

  if (!result) {
    res.status(400).json({ error: "Choose an active merchant" });
    return;
  }
  if ("archived" in result) {
    res.status(409).json({ error: "This order request was already archived" });
    return;
  }
  res
    .status(result.duplicate ? 200 : 201)
    .json(CreateOrderResponse.parse(result.order));
});

router.get("/orders/:id", async (req, res): Promise<void> => {
  const params = GetOrderParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [row] = await db
    .select({ order: ordersTable, merchantName: merchantsTable.businessName })
    .from(ordersTable)
    .innerJoin(merchantsTable, eq(ordersTable.merchantId, merchantsTable.id))
    .where(
      and(eq(ordersTable.id, params.data.id), isNull(ordersTable.deletedAt)),
    );
  if (!row) {
    res.status(404).json({ error: "Order not found" });
    return;
  }
  const history = await db
    .select()
    .from(orderStatusHistoryTable)
    .where(eq(orderStatusHistoryTable.orderId, params.data.id))
    .orderBy(desc(orderStatusHistoryTable.changedAt));
  res.json(
    GetOrderResponse.parse({
      ...toOrderDto(row.order, row.merchantName),
      statusHistory: history.map(toStatusHistoryDto),
    }),
  );
});

router.patch("/orders/:id", async (req, res): Promise<void> => {
  const params = UpdateOrderParams.safeParse(req.params);
  const parsed = UpdateOrderBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updated = await db.transaction(async (tx) => {
    const { plannedDate, ...orderUpdate } = parsed.data;
    const [current] = await tx
      .select()
      .from(ordersTable)
      .where(
        and(
          eq(ordersTable.id, params.data.id),
          isNull(ordersTable.deletedAt),
        ),
      )
      .for("update");
    if (!current) return null;
    const nextMerchantId = parsed.data.merchantId ?? current.merchantId;
    const [merchant] = await tx
      .select()
      .from(merchantsTable)
      .where(eq(merchantsTable.id, nextMerchantId));
    if (!merchant || (!merchant.isActive && nextMerchantId !== current.merchantId)) {
      return { invalidMerchant: true as const };
    }

    const nextStatus = parsed.data.status ?? current.status;
    const statusChanged = nextStatus !== current.status;
    const now = new Date();
    const [order] = await tx
      .update(ordersTable)
      .set({
        ...orderUpdate,
        ...(plannedDate !== undefined
          ? {
              plannedDate:
                plannedDate === null
                  ? null
                  : toCalendarDate(plannedDate),
            }
          : {}),
        updatedAt: now,
        ...(statusChanged
          ? { deliveredAt: nextStatus === "delivered" ? now : null }
          : {}),
      })
      .where(eq(ordersTable.id, current.id))
      .returning();
    if (!order) throw new Error("Order could not be updated");

    if (statusChanged) {
      await tx.insert(orderStatusHistoryTable).values({
        orderId: current.id,
        previousStatus: current.status,
        newStatus: nextStatus,
        changedAt: now,
        notes: parsed.data.notes ?? null,
      });
    }
    return { order: toOrderDto(order, merchant.businessName) };
  });

  if (!updated) {
    res.status(404).json({ error: "Order not found" });
    return;
  }
  if ("invalidMerchant" in updated) {
    res.status(400).json({ error: "Choose a valid active merchant" });
    return;
  }
  res.json(UpdateOrderResponse.parse(updated.order));
});

router.delete("/orders/:id", async (req, res): Promise<void> => {
  const params = ArchiveOrderParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [archived] = await db
    .update(ordersTable)
    .set({ deletedAt: new Date(), updatedAt: new Date() })
    .where(
      and(
        eq(ordersTable.id, params.data.id),
        isNull(ordersTable.deletedAt),
      ),
    )
    .returning({ id: ordersTable.id });
  if (!archived) {
    res.status(404).json({ error: "Order not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
