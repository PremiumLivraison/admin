import { and, desc, eq, ilike, isNull, or } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CreateMerchantBody,
  CreateMerchantResponse,
  GetMerchantParams,
  GetMerchantResponse,
  GetMerchantSummaryParams,
  GetMerchantSummaryResponse,
  ListMerchantsQueryParams,
  ListMerchantsResponse,
  UpdateMerchantBody,
  UpdateMerchantParams,
  UpdateMerchantResponse,
} from "@workspace/api-zod";
import {
  db,
  merchantPaymentsTable,
  merchantsTable,
  ordersTable,
} from "@workspace/db";
import {
  getMerchantLedger,
  toMerchantDto,
  toOrderDto,
  toPaymentDto,
} from "../lib/livreson";

const router: IRouter = Router();

async function buildMerchantDetail(merchantId: number) {
  const [merchant] = await db
    .select()
    .from(merchantsTable)
    .where(eq(merchantsTable.id, merchantId));
  if (!merchant) return null;

  const [orders, payments, ledger] = await Promise.all([
    db
      .select({ order: ordersTable, merchantName: merchantsTable.businessName })
      .from(ordersTable)
      .innerJoin(merchantsTable, eq(ordersTable.merchantId, merchantsTable.id))
      .where(
        and(
          eq(ordersTable.merchantId, merchantId),
          isNull(ordersTable.deletedAt),
        ),
      )
      .orderBy(desc(ordersTable.createdAt))
      .limit(300),
    db
      .select({
        payment: merchantPaymentsTable,
        merchantName: merchantsTable.businessName,
      })
      .from(merchantPaymentsTable)
      .innerJoin(
        merchantsTable,
        eq(merchantPaymentsTable.merchantId, merchantsTable.id),
      )
      .where(eq(merchantPaymentsTable.merchantId, merchantId))
      .orderBy(desc(merchantPaymentsTable.paymentDate))
      .limit(300),
    getMerchantLedger(merchantId),
  ]);

  return {
    ...toMerchantDto(merchant),
    ...ledger,
    orders: orders.map(({ order, merchantName }) =>
      toOrderDto(order, merchantName),
    ),
    payments: payments.map(({ payment, merchantName }) =>
      toPaymentDto(payment, merchantName),
    ),
  };
}

router.get("/merchants", async (req, res): Promise<void> => {
  const query = ListMerchantsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const filters = [];
  if (query.data.activeOnly) filters.push(eq(merchantsTable.isActive, true));
  const search = query.data.search?.trim();
  if (search) {
    filters.push(
      or(
        ilike(merchantsTable.businessName, `%${search}%`),
        ilike(merchantsTable.contactName, `%${search}%`),
        ilike(merchantsTable.phone, `%${search}%`),
      )!,
    );
  }
  const merchants = await db
    .select()
    .from(merchantsTable)
    .where(filters.length ? and(...filters) : undefined)
    .orderBy(merchantsTable.businessName)
    .limit(300);
  const result = await Promise.all(
    merchants.map(async (merchant) => ({
      ...toMerchantDto(merchant),
      ...(await getMerchantLedger(merchant.id)),
    })),
  );
  res.json(ListMerchantsResponse.parse(result));
});

router.post("/merchants", async (req, res): Promise<void> => {
  const parsed = CreateMerchantBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [merchant] = await db
    .insert(merchantsTable)
    .values(parsed.data)
    .returning();
  if (!merchant) throw new Error("Merchant could not be created");
  res.status(201).json(CreateMerchantResponse.parse(toMerchantDto(merchant)));
});

router.get("/merchants/:id/summary", async (req, res): Promise<void> => {
  const params = GetMerchantSummaryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const merchant = await buildMerchantDetail(params.data.id);
  if (!merchant) {
    res.status(404).json({ error: "Merchant not found" });
    return;
  }
  res.json(GetMerchantSummaryResponse.parse(merchant));
});

router.get("/merchants/:id", async (req, res): Promise<void> => {
  const params = GetMerchantParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const merchant = await buildMerchantDetail(params.data.id);
  if (!merchant) {
    res.status(404).json({ error: "Merchant not found" });
    return;
  }
  res.json(GetMerchantResponse.parse(merchant));
});

router.patch("/merchants/:id", async (req, res): Promise<void> => {
  const params = UpdateMerchantParams.safeParse(req.params);
  const parsed = UpdateMerchantBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [merchant] = await db
    .update(merchantsTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(eq(merchantsTable.id, params.data.id))
    .returning();
  if (!merchant) {
    res.status(404).json({ error: "Merchant not found" });
    return;
  }
  res.json(UpdateMerchantResponse.parse(toMerchantDto(merchant)));
});

export default router;
