import {
  and,
  count,
  desc,
  eq,
  gte,
  inArray,
  isNull,
  lt,
  sql,
} from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  CreatePaymentBody,
  CreatePaymentResponse,
  ExportReportCsvQueryParams,
  GetDashboardQueryParams,
  GetDashboardResponse,
  GetOwnerResponse,
  GetReportsQueryParams,
  GetReportsResponse,
  GetSettingsResponse,
  ListPaymentsQueryParams,
  ListPaymentsResponse,
  ReversePaymentBody,
  ReversePaymentParams,
  ReversePaymentResponse,
  StartBusinessWorkflowBody,
  StartBusinessWorkflowResponse,
  UpdateSettingsBody,
  UpdateSettingsResponse,
} from "@workspace/api-zod";
import {
  appSettingsTable,
  db,
  merchantPaymentsTable,
  merchantsTable,
  ordersTable,
  workflowDaysTable,
} from "@workspace/db";
import {
  createReference,
  dateInBusinessTimezone,
  ensureSettings,
  getDateBounds,
  getOverallOutstandingCentimes,
  getPeriodRange,
  toOrderDto,
  toPaymentDto,
  toCalendarDate,
  toSettingsDto,
} from "../lib/livreson";
import { clerkClient, getAuth } from "@clerk/express";

const router: IRouter = Router();

async function getWorkflowState(businessDate: string) {
  const [row] = await db
    .select()
    .from(workflowDaysTable)
    .where(eq(workflowDaysTable.businessDate, businessDate));
  const bounds = getDateBounds(businessDate, businessDate);
  const [prepared] = await db
    .select({ count: count() })
    .from(ordersTable)
    .where(
      and(
        isNull(ordersTable.deletedAt),
        inArray(ordersTable.status, ["ready", "out_for_delivery"]),
        gte(ordersTable.createdAt, bounds.start),
        lt(ordersTable.createdAt, bounds.endExclusive),
      ),
    );
  return {
    businessDate,
    collectionStartedAt: row?.collectionStartedAt?.toISOString() ?? null,
    deliveryStartedAt: row?.deliveryStartedAt?.toISOString() ?? null,
    preparedOrders: Number(prepared?.count ?? 0),
  };
}

router.get("/auth/owner", async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Sign in to continue" });
    return;
  }
  const user = await clerkClient.users.getUser(userId);
  const email = user.emailAddresses.find(
    (address) =>
      address.emailAddress.trim().toLowerCase() ===
        process.env.OWNER_EMAIL?.trim().toLowerCase() &&
      address.verification?.status === "verified",
  )?.emailAddress;
  if (!email) {
    res.status(403).json({ error: "This account is not authorized" });
    return;
  }
  res.json(
    GetOwnerResponse.parse({
      userId,
      email,
      name: [user.firstName, user.lastName].filter(Boolean).join(" ") || null,
    }),
  );
});

router.get("/dashboard", async (req, res): Promise<void> => {
  const query = GetDashboardQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const period = query.data.period ?? "day";
  const businessDate = query.data.date
    ? toCalendarDate(query.data.date)
    : dateInBusinessTimezone();
  const range = getPeriodRange(period, businessDate);
  const bounds = getDateBounds(range.from, range.to);

  const [rangeOrders, deliveredRows, recentRows, activeCount, outstanding, workflow] =
    await Promise.all([
      db
        .select({ status: ordersTable.status })
        .from(ordersTable)
        .where(
          and(
            isNull(ordersTable.deletedAt),
            gte(ordersTable.createdAt, bounds.start),
            lt(ordersTable.createdAt, bounds.endExclusive),
          ),
        ),
      db
        .select({ deliveryFeeCentimes: ordersTable.deliveryFeeCentimes })
        .from(ordersTable)
        .where(
          and(
            eq(ordersTable.status, "delivered"),
            isNull(ordersTable.deletedAt),
            gte(ordersTable.deliveredAt, bounds.start),
            lt(ordersTable.deliveredAt, bounds.endExclusive),
          ),
        ),
      db
        .select({ order: ordersTable, merchantName: merchantsTable.businessName })
        .from(ordersTable)
        .innerJoin(merchantsTable, eq(ordersTable.merchantId, merchantsTable.id))
        .where(isNull(ordersTable.deletedAt))
        .orderBy(desc(ordersTable.createdAt))
        .limit(6),
      db
        .select({ count: count() })
        .from(merchantsTable)
        .where(eq(merchantsTable.isActive, true)),
      getOverallOutstandingCentimes(),
      getWorkflowState(businessDate),
    ]);

  const statusCount = (status: string) =>
    rangeOrders.filter((order) => order.status === status).length;
  const response = {
    period,
    from: range.from,
    to: range.to,
    totalOrders: rangeOrders.length,
    awaitingOrders:
      statusCount("new") +
      statusCount("ready") +
      statusCount("out_for_delivery"),
    deliveredOrders: statusCount("delivered"),
    failedOrders: statusCount("failed"),
    cancelledOrders: statusCount("cancelled"),
    deliveryRevenueCentimes: deliveredRows.reduce(
      (sum, row) => sum + row.deliveryFeeCentimes,
      0,
    ),
    outstandingCentimes: outstanding,
    activeMerchants: Number(activeCount[0]?.count ?? 0),
    preparedOrders: workflow.preparedOrders,
    workflow,
    recentOrders: recentRows.map(({ order, merchantName }) =>
      toOrderDto(order, merchantName),
    ),
  };
  res.json(GetDashboardResponse.parse(response));
});

router.post("/workflow/start", async (req, res): Promise<void> => {
  const parsed = StartBusinessWorkflowBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const businessDate = dateInBusinessTimezone();
  const now = new Date();
  const workflow = await db.transaction(async (tx) => {
    await tx
      .insert(workflowDaysTable)
      .values({ businessDate })
      .onConflictDoNothing();
    const [current] = await tx
      .select()
      .from(workflowDaysTable)
      .where(eq(workflowDaysTable.businessDate, businessDate))
      .for("update");
    if (!current) throw new Error("Could not create business workflow");
    const column =
      parsed.data.mode === "collection"
        ? workflowDaysTable.collectionStartedAt
        : workflowDaysTable.deliveryStartedAt;
    const startedAt =
      parsed.data.mode === "collection"
        ? current.collectionStartedAt
        : current.deliveryStartedAt;
    if (!startedAt) {
      await tx
        .update(workflowDaysTable)
        .set({
          [parsed.data.mode === "collection"
            ? "collectionStartedAt"
            : "deliveryStartedAt"]: now,
          updatedAt: now,
        })
        .where(eq(workflowDaysTable.id, current.id));
    }
    return current;
  });
  void workflow;
  res.json(
    StartBusinessWorkflowResponse.parse(
      await getWorkflowState(businessDate),
    ),
  );
});

router.get("/payments", async (req, res): Promise<void> => {
  const query = ListPaymentsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const filters = [];
  if (query.data.merchantId) {
    filters.push(eq(merchantPaymentsTable.merchantId, query.data.merchantId));
  }
  const from = query.data.from ? toCalendarDate(query.data.from) : undefined;
  const to = query.data.to ? toCalendarDate(query.data.to) : undefined;
  if (from) filters.push(gte(merchantPaymentsTable.paymentDate, from));
  if (to) filters.push(lt(merchantPaymentsTable.paymentDate, addDate(to, 1)));
  const rows = await db
    .select({
      payment: merchantPaymentsTable,
      merchantName: merchantsTable.businessName,
    })
    .from(merchantPaymentsTable)
    .innerJoin(
      merchantsTable,
      eq(merchantPaymentsTable.merchantId, merchantsTable.id),
    )
    .where(filters.length ? and(...filters) : undefined)
    .orderBy(desc(merchantPaymentsTable.paymentDate), desc(merchantPaymentsTable.id))
    .limit(500);
  res.json(
    ListPaymentsResponse.parse(
      rows.map(({ payment, merchantName }) =>
        toPaymentDto(payment, merchantName),
      ),
    ),
  );
});

function addDate(date: string, days: number): string {
  const [year, month, day] = date.split("-").map(Number);
  const next = new Date(Date.UTC(year, month - 1, day + days));
  return `${next.getUTCFullYear()}-${String(next.getUTCMonth() + 1).padStart(2, "0")}-${String(next.getUTCDate()).padStart(2, "0")}`;
}

router.post("/payments", async (req, res): Promise<void> => {
  const parsed = CreatePaymentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  let outcome:
    | { kind: "missing" }
    | { kind: "overpayment"; outstanding: number }
    | { kind: "saved" | "duplicate"; payment: typeof merchantPaymentsTable.$inferSelect; merchantName: string };
  try {
    outcome = await db.transaction(async (tx) => {
      const [existing] = await tx
        .select({
          payment: merchantPaymentsTable,
          merchantName: merchantsTable.businessName,
        })
        .from(merchantPaymentsTable)
        .innerJoin(
          merchantsTable,
          eq(merchantPaymentsTable.merchantId, merchantsTable.id),
        )
        .where(eq(merchantPaymentsTable.idempotencyKey, parsed.data.idempotencyKey));
      if (existing) {
        return {
          kind: "duplicate" as const,
          payment: existing.payment,
          merchantName: existing.merchantName,
        };
      }

      const [merchant] = await tx
        .select()
        .from(merchantsTable)
        .where(eq(merchantsTable.id, parsed.data.merchantId))
        .for("update");
      if (!merchant) return { kind: "missing" as const };

      // Re-check after acquiring the merchant lock so repeated concurrent submissions
      // for this merchant return the original record instead of creating another one.
      const [afterLock] = await tx
        .select({
          payment: merchantPaymentsTable,
          merchantName: merchantsTable.businessName,
        })
        .from(merchantPaymentsTable)
        .innerJoin(
          merchantsTable,
          eq(merchantPaymentsTable.merchantId, merchantsTable.id),
        )
        .where(eq(merchantPaymentsTable.idempotencyKey, parsed.data.idempotencyKey));
      if (afterLock) {
        return {
          kind: "duplicate" as const,
          payment: afterLock.payment,
          merchantName: afterLock.merchantName,
        };
      }

      const ledger = await getMerchantLedgerForTransaction(tx, merchant.id);
      if (
        parsed.data.amountCentimes > ledger.outstandingCentimes &&
        !parsed.data.confirmOverpayment
      ) {
        return {
          kind: "overpayment" as const,
          outstanding: ledger.outstandingCentimes,
        };
      }

      const [payment] = await tx
        .insert(merchantPaymentsTable)
        .values({
          merchantId: parsed.data.merchantId,
          idempotencyKey: parsed.data.idempotencyKey,
          amountCentimes: parsed.data.amountCentimes,
          paymentDate: toCalendarDate(parsed.data.paymentDate),
          method: parsed.data.method,
          transactionReference: parsed.data.transactionReference,
          notes: parsed.data.notes,
          reference: createReference("PL-P"),
        })
        .returning();
      if (!payment) throw new Error("Payment could not be recorded");
      return {
        kind: "saved" as const,
        payment,
        merchantName: merchant.businessName,
      };
    });
  } catch (error) {
    if ((error as { code?: string }).code === "23505") {
      const [existing] = await db
        .select({
          payment: merchantPaymentsTable,
          merchantName: merchantsTable.businessName,
        })
        .from(merchantPaymentsTable)
        .innerJoin(
          merchantsTable,
          eq(merchantPaymentsTable.merchantId, merchantsTable.id),
        )
        .where(eq(merchantPaymentsTable.idempotencyKey, parsed.data.idempotencyKey));
      if (existing) {
        res
          .status(200)
          .json(
            CreatePaymentResponse.parse(
              toPaymentDto(existing.payment, existing.merchantName),
            ),
          );
        return;
      }
    }
    throw error;
  }

  if (outcome.kind === "missing") {
    res.status(404).json({ error: "Merchant not found" });
    return;
  }
  if (outcome.kind === "overpayment") {
    res.status(409).json({
      error: "Payment exceeds the outstanding balance. Confirm to record it anyway.",
      code: "OVERPAYMENT_CONFIRMATION_REQUIRED",
      outstandingCentimes: outcome.outstanding,
    });
    return;
  }
  res
    .status(outcome.kind === "duplicate" ? 200 : 201)
    .json(
      CreatePaymentResponse.parse(
        toPaymentDto(outcome.payment, outcome.merchantName),
      ),
    );
});

async function getMerchantLedgerForTransaction(
  tx: Parameters<Parameters<typeof db.transaction>[0]>[0],
  merchantId: number,
) {
  const [fees] = await tx
    .select({
      total: sql<number>`coalesce(sum(${ordersTable.deliveryFeeCentimes}), 0)`,
    })
    .from(ordersTable)
    .where(
      and(
        eq(ordersTable.merchantId, merchantId),
        eq(ordersTable.status, "delivered"),
        isNull(ordersTable.deletedAt),
      ),
    );
  const [payments] = await tx
    .select({
      total: sql<number>`coalesce(sum(${merchantPaymentsTable.amountCentimes}), 0)`,
    })
    .from(merchantPaymentsTable)
    .where(
      and(
        eq(merchantPaymentsTable.merchantId, merchantId),
        eq(merchantPaymentsTable.status, "confirmed"),
      ),
    );
  const totalFeesCentimes = Number(fees?.total ?? 0);
  const totalPaymentsCentimes = Number(payments?.total ?? 0);
  return {
    outstandingCentimes: totalFeesCentimes - totalPaymentsCentimes,
  };
}

router.post("/payments/:id/reverse", async (req, res): Promise<void> => {
  const params = ReversePaymentParams.safeParse(req.params);
  const parsed = ReversePaymentBody.safeParse(req.body);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const result = await db.transaction(async (tx) => {
    const [current] = await tx
      .select({
        payment: merchantPaymentsTable,
        merchantName: merchantsTable.businessName,
      })
      .from(merchantPaymentsTable)
      .innerJoin(
        merchantsTable,
        eq(merchantPaymentsTable.merchantId, merchantsTable.id),
      )
      .where(eq(merchantPaymentsTable.id, params.data.id))
      .for("update");
    if (!current) return null;
    if (current.payment.status === "reversed") return current;
    const [reversed] = await tx
      .update(merchantPaymentsTable)
      .set({
        status: "reversed",
        reversedAt: new Date(),
        reversalReason: parsed.data.reason,
      })
      .where(eq(merchantPaymentsTable.id, params.data.id))
      .returning();
    if (!reversed) throw new Error("Payment could not be reversed");
    return { payment: reversed, merchantName: current.merchantName };
  });
  if (!result) {
    res.status(404).json({ error: "Payment not found" });
    return;
  }
  res.json(
    ReversePaymentResponse.parse(
      toPaymentDto(result.payment, result.merchantName),
    ),
  );
});

router.get("/settings", async (_req, res): Promise<void> => {
  const settings = await ensureSettings();
  res.json(GetSettingsResponse.parse(toSettingsDto(settings)));
});

router.put("/settings", async (req, res): Promise<void> => {
  const parsed = UpdateSettingsBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  await ensureSettings();
  const [settings] = await db
    .update(appSettingsTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(eq(appSettingsTable.id, 1))
    .returning();
  if (!settings) throw new Error("Business settings could not be saved");
  res.json(UpdateSettingsResponse.parse(toSettingsDto(settings)));
});

router.get("/reports", async (req, res): Promise<void> => {
  const query = GetReportsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const from = toCalendarDate(query.data.from);
  const to = toCalendarDate(query.data.to);
  const bounds = getDateBounds(from, to);
  const orderDateFilter = and(
    isNull(ordersTable.deletedAt),
    gte(ordersTable.createdAt, bounds.start),
    lt(ordersTable.createdAt, bounds.endExclusive),
  );
  const deliveredFilter = and(
    eq(ordersTable.status, "delivered"),
    isNull(ordersTable.deletedAt),
    gte(ordersTable.deliveredAt, bounds.start),
    lt(ordersTable.deliveredAt, bounds.endExclusive),
  );

  const [
    statusRows,
    merchantRevenue,
    areaRevenue,
    paymentRows,
    outstanding,
  ] = await Promise.all([
    db
      .select({ status: ordersTable.status, count: count() })
      .from(ordersTable)
      .where(orderDateFilter)
      .groupBy(ordersTable.status),
    db
      .select({
        merchantId: merchantsTable.id,
        merchantName: merchantsTable.businessName,
        count: count(),
        revenueCentimes: sql<number>`coalesce(sum(${ordersTable.deliveryFeeCentimes}), 0)`,
      })
      .from(ordersTable)
      .innerJoin(merchantsTable, eq(ordersTable.merchantId, merchantsTable.id))
      .where(deliveredFilter)
      .groupBy(merchantsTable.id, merchantsTable.businessName)
      .orderBy(desc(sql`sum(${ordersTable.deliveryFeeCentimes})`)),
    db
      .select({
        areaType: ordersTable.areaType,
        count: count(),
        revenueCentimes: sql<number>`coalesce(sum(${ordersTable.deliveryFeeCentimes}), 0)`,
      })
      .from(ordersTable)
      .where(deliveredFilter)
      .groupBy(ordersTable.areaType),
    db
      .select({ amountCentimes: merchantPaymentsTable.amountCentimes })
      .from(merchantPaymentsTable)
      .where(
        and(
          eq(merchantPaymentsTable.status, "confirmed"),
          gte(merchantPaymentsTable.paymentDate, from),
          lt(merchantPaymentsTable.paymentDate, addDate(to, 1)),
        ),
      ),
    getOverallOutstandingCentimes(),
  ]);

  const counts = new Map(
    statusRows.map((row) => [row.status, Number(row.count)]),
  );
  const statuses = [
    "new",
    "ready",
    "out_for_delivery",
    "delivered",
    "failed",
    "cancelled",
  ] as const;
  const response = {
    from,
    to,
    completedDeliveries: merchantRevenue.reduce(
      (sum, row) => sum + Number(row.count),
      0,
    ),
    deliveryRevenueCentimes: merchantRevenue.reduce(
      (sum, row) => sum + Number(row.revenueCentimes),
      0,
    ),
    merchantPaymentsCentimes: paymentRows.reduce(
      (sum, row) => sum + row.amountCentimes,
      0,
    ),
    outstandingCentimes: outstanding,
    ordersByStatus: statuses.map((status) => ({
      status,
      count: counts.get(status) ?? 0,
    })),
    revenueByMerchant: merchantRevenue.map((row) => ({
      ...row,
      count: Number(row.count),
      revenueCentimes: Number(row.revenueCentimes),
    })),
    revenueByArea: areaRevenue.map((row) => ({
      ...row,
      count: Number(row.count),
      revenueCentimes: Number(row.revenueCentimes),
    })),
  };
  res.json(GetReportsResponse.parse(response));
});

router.get("/reports/export.csv", async (req, res): Promise<void> => {
  const query = ExportReportCsvQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }
  const from = toCalendarDate(query.data.from);
  const to = toCalendarDate(query.data.to);
  const bounds = getDateBounds(from, to);
  const [orders, payments] = await Promise.all([
    db
      .select({ order: ordersTable, merchantName: merchantsTable.businessName })
      .from(ordersTable)
      .innerJoin(merchantsTable, eq(ordersTable.merchantId, merchantsTable.id))
      .where(
        and(
          isNull(ordersTable.deletedAt),
          gte(ordersTable.createdAt, bounds.start),
          lt(ordersTable.createdAt, bounds.endExclusive),
        ),
      )
      .orderBy(desc(ordersTable.createdAt)),
    db
      .select({
        payment: merchantPaymentsTable,
        merchantName: merchantsTable.businessName,
      })
      .from(merchantPaymentsTable)
      .innerJoin(
        merchantsTable,
        eq(merchantPaymentsTable.merchantId, merchantsTable.id),
      )
      .where(
        and(
          eq(merchantPaymentsTable.status, "confirmed"),
          gte(merchantPaymentsTable.paymentDate, from),
          lt(merchantPaymentsTable.paymentDate, addDate(to, 1)),
        ),
      )
      .orderBy(desc(merchantPaymentsTable.paymentDate)),
  ]);
  const escapeCsv = (value: unknown) => {
    let text = String(value ?? "");
    if (/^[\s]*[=+\-@]/.test(text)) text = `'${text}`;
    return `"${text.replaceAll('"', '""')}"`;
  };
  const rows = [
    [
      "record_type",
      "reference",
      "date",
      "merchant",
      "customer",
      "status",
      "area",
      "amount_centimes",
      "currency",
    ],
    ...orders.map(({ order, merchantName }) => [
      "order",
      order.reference,
      dateInBusinessTimezone(order.createdAt),
      merchantName,
      order.customerName,
      order.status,
      order.areaType,
      order.status === "delivered" ? order.deliveryFeeCentimes : 0,
      "MAD",
    ]),
    ...payments.map(({ payment, merchantName }) => [
      "payment",
      payment.reference,
      payment.paymentDate,
      merchantName,
      "",
      payment.status,
      "",
      payment.amountCentimes,
      "MAD",
    ]),
  ];
  const csv = `\uFEFF${rows.map((row) => row.map(escapeCsv).join(",")).join("\r\n")}`;
  res
    .status(200)
    .setHeader("Content-Type", "text/csv; charset=utf-8")
    .setHeader(
      "Content-Disposition",
      `attachment; filename="premium-livreson-${from}-${to}.csv"`,
    )
    .send(csv);
});

export default router;
