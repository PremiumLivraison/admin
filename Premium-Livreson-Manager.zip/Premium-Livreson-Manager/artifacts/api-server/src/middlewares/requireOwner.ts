import { clerkClient, getAuth } from "@clerk/express";
import type { RequestHandler } from "express";

export const requireOwner: RequestHandler = async (req, res, next) => {
  const ownerEmail = process.env.OWNER_EMAIL?.trim().toLowerCase();
  if (!ownerEmail) {
    res.status(503).json({ error: "Owner access is not configured" });
    return;
  }

  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Sign in to continue" });
    return;
  }

  try {
    const user = await clerkClient.users.getUser(userId);
    const authorized = user.emailAddresses.some(
      (address) =>
        address.emailAddress.trim().toLowerCase() === ownerEmail &&
        address.verification?.status === "verified",
    );
    if (!authorized) {
      res.status(403).json({ error: "This account is not authorized" });
      return;
    }
    next();
  } catch (error) {
    req.log.error({ err: error }, "Owner identity verification failed");
    res.status(401).json({ error: "Unable to verify owner access" });
  }
};
