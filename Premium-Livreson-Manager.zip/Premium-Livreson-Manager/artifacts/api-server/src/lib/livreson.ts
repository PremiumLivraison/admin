import { randomUUID } from "node:crypto";
import { and, eq, isNull, sql } from "drizzle-orm";
import {
  appSettingsTable,
  db,
  merchantPaymentsTable,
  merchantsTable,
  ordersTable,
} from "@workspace/db";

export const BUSINESS_TIMEZONE = "Africa/Casablanca";

export function dateInBusinessTimezone(date = new Date()): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: BUSINESS_TIMEZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const part = (name: string) =>
    parts.find((item) => item.type === name)?.value ?? "";
  return `${part("year")}-${part("month")}-${part("day")}`;
}

export function toCalendarDate(value: string | Date): string {
  return value instanceof Date ? value.toISOString().slice(0, 10) : value;
}

function startOfBusinessDay(date: string): Date {
  const [year, month, day] = date.split("-").map(Number);
  let candidate = Date.UTC(year, month - 1, day);
  const formatter = new Intl.DateTimeFormat("en-GB", {
    timeZone: BUSINESS_TIMEZONE,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  });
  for (let iteration = 0; iteration < 3; iteration += 1) {
    const parts = formatter.formatToParts(new Date(candidate));
    const part = (name: string) =>
      Number(parts.find((item) => item.type === name)?.value ?? 0);
    const observedAsUtc = Date.UTC(
      part("year"),
      part("month") - 1,
      part("day"),
      part("hour"),
      part("minute"),
      part("second"),
    );
    candidate += Date.UTC(year, month - 1, day) - observedAsUtc;
  }
  return new Date(candidate);
}

function addCalendarDays(date: string, days: number): string {
  const [year, month, day] = date.split("-").map(Number);
  const result = new Date(Date.UTC(year, month - 1, day + days));
  return `${result.getUTCFullYear()}-${String(result.getUTCMonth() + 1).padStart(2, "0")}-${String(result.getUTCDate()).padStart(2, "0")}`;
}

export function getDateBounds(from: string, to: string): {
  start: Date;
  endExclusive: Date;
} {
  return {
    start: startOfBusinessDay(from),
    endExclusive: startOfBusinessDay(addCalendarDays(to, 1)),
  };
}

export function getPeriodRange(
  period: "day" | "week" | "month",
  date = dateInBusinessTimezone(),
): { from: string; to: string } {
  if (period === "day") return { from: date, to: date };
  const [year, month, day] = date.split("-").map(Number);
  const selected = new Date(Date.UTC(year, month - 1, day));
  if (period === "month") {
    const from = `${year}-${String(month).padStart(2, "0")}-01`;
    const lastDay = new Date(Date.UTC(year, month, 0)).getUTCDate();
    return {
      from,
      to: `${year}-${String(month).padStart(2, "0")}-${String(lastDay).padStart(2, "0")}`,
    };
  }
  const dayOfWeek = selected.getUTCDay();
  const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
  return {
    from: addCalendarDays(date, mondayOffset),
    to: addCalendarDays(date, mondayOffset + 6),
  };
}

export async function ensureSettings() {
  await db.insert(appSettingsTable).values({ id: 1 }).onConflictDoNothing();
  const [settings] = await db
    .select()
    .from(appSettingsTable)
    .where(eq(appSettingsTable.id, 1));
  if (!settings) throw new Error("Business settings are unavailable");
  return settings;
}

export function toSettingsDto(row: typeof appSettingsTable.$inferSelect) {
  return { ...row, updatedAt: row.updatedAt.toISOString() };
}

export function toMerchantDto(row: typeof merchantsTable.$inferSelect) {
  return {
    id: row.id,
    businessName: row.businessName,
    contactName: row.contactName,
    phone: row.phone,
    address: row.address,
    notes: row.notes,
    isActive: row.isActive,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export function toOrderDto(
  row: typeof ordersTable.$inferSelect,
  merchantName: string,
) {
  return {
    id: row.id,
    reference: row.reference,
    merchantId: row.merchantId,
    merchantName,
    customerName: row.customerName,
    customerPhone: row.customerPhone,
    city: row.city,
    areaType: row.areaType,
    deliveryAddress: row.deliveryAddress,
    productDescription: row.productDescription,
    productPriceCentimes: row.productPriceCentimes,
    amountToCollectCentimes: row.amountToCollectCentimes,
    deliveryFeeCentimes: row.deliveryFeeCentimes,
    plannedDate: row.plannedDate,
    status: row.status,
    notes: row.notes,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
    deliveredAt: row.deliveredAt?.toISOString() ?? null,
  };
}

export function toPaymentDto(
  row: typeof merchantPaymentsTable.$inferSelect,
  merchantName: string,
) {
  return {
    id: row.id,
    merchantId: row.merchantId,
    merchantName,
    reference: row.reference,
    amountCentimes: row.amountCentimes,
    paymentDate: row.paymentDate,
    method: row.method,
    transactionReference: row.transactionReference,
    notes: row.notes,
    status: row.status,
    reversedAt: row.reversedAt?.toISOString() ?? null,
    reversalReason: row.reversalReason,
    createdAt: row.createdAt.toISOString(),
  };
}

export function toStatusHistoryDto(
  row: {
    previousStatus: string | null;
    newStatus: string;
    changedAt: Date;
    notes: string | null;
  },
) {
  return {
    previousStatus: row.previousStatus,
    newStatus: row.newStatus,
    changedAt: row.changedAt.toISOString(),
    notes: row.notes,
  };
}

export async function getMerchantLedger(merchantId: number) {
  const [feeTotals] = await db
    .select({
      count: sql<number>`count(*)`,
      total: sql<number>`coalesce(sum(${ordersTable.deliveryFeeCentimes}), 0)`,
    })
    .from(ordersTable)
    .where(
      and(
        eq(ordersTable.merchantId, merchantId),
        eq(ordersTable.status, "delivered"),
        isNull(ordersTable.deletedAt),
      ),
    );
  const [paymentTotals] = await db
    .select({
      total: sql<number>`coalesce(sum(${merchantPaymentsTable.amountCentimes}), 0)`,
    })
    .from(merchantPaymentsTable)
    .where(
      and(
        eq(merchantPaymentsTable.merchantId, merchantId),
        eq(merchantPaymentsTable.status, "confirmed"),
      ),
    );
  const totalFeesCentimes = Number(feeTotals?.total ?? 0);
  const totalPaymentsCentimes = Number(paymentTotals?.total ?? 0);
  return {
    deliveredCount: Number(feeTotals?.count ?? 0),
    totalFeesCentimes,
    totalPaymentsCentimes,
    outstandingCentimes: totalFeesCentimes - totalPaymentsCentimes,
  };
}

export async function getOverallOutstandingCentimes() {
  const feeRows = await db
    .select({
      merchantId: ordersTable.merchantId,
      total: sql<number>`coalesce(sum(${ordersTable.deliveryFeeCentimes}), 0)`,
    })
    .from(ordersTable)
    .where(
      and(
        eq(ordersTable.status, "delivered"),
        isNull(ordersTable.deletedAt),
      ),
    )
    .groupBy(ordersTable.merchantId);
  const paymentRows = await db
    .select({
      merchantId: merchantPaymentsTable.merchantId,
      total: sql<number>`coalesce(sum(${merchantPaymentsTable.amountCentimes}), 0)`,
    })
    .from(merchantPaymentsTable)
    .where(eq(merchantPaymentsTable.status, "confirmed"))
    .groupBy(merchantPaymentsTable.merchantId);
  const fees = new Map(
    feeRows.map((row) => [row.merchantId, Number(row.total)]),
  );
  const payments = new Map(
    paymentRows.map((row) => [row.merchantId, Number(row.total)]),
  );
  const merchantIds = new Set([...fees.keys(), ...payments.keys()]);
  return [...merchantIds].reduce(
    (total, merchantId) =>
      total + Math.max(0, (fees.get(merchantId) ?? 0) - (payments.get(merchantId) ?? 0)),
    0,
  );
}

export function createReference(prefix: "PL-O" | "PL-P"): string {
  const suffix = randomUUID().replaceAll("-", "").slice(0, 10).toUpperCase();
  return `${prefix}-${dateInBusinessTimezone().replaceAll("-", "")}-${suffix}`;
}
