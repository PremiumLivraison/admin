import {
  boolean,
  date,
  index,
  integer,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const orderStatusEnum = pgEnum("livreson_order_status", [
  "new",
  "ready",
  "out_for_delivery",
  "delivered",
  "failed",
  "cancelled",
]);

export const areaTypeEnum = pgEnum("livreson_area_type", [
  "fes",
  "surrounding",
]);

export const paymentMethodEnum = pgEnum("livreson_payment_method", [
  "cash",
  "bank_transfer",
  "other",
]);

export const paymentStatusEnum = pgEnum("livreson_payment_status", [
  "confirmed",
  "reversed",
]);

export const merchantsTable = pgTable(
  "livreson_merchants",
  {
    id: serial("id").primaryKey(),
    businessName: text("business_name").notNull(),
    contactName: text("contact_name").notNull(),
    phone: text("phone").notNull(),
    address: text("address"),
    notes: text("notes"),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [index("livreson_merchants_active_idx").on(table.isActive)],
);

export const ordersTable = pgTable(
  "livreson_orders",
  {
    id: serial("id").primaryKey(),
    reference: text("reference").notNull().unique(),
    idempotencyKey: text("idempotency_key").notNull().unique(),
    merchantId: integer("merchant_id")
      .notNull()
      .references(() => merchantsTable.id, { onDelete: "restrict" }),
    customerName: text("customer_name").notNull(),
    customerPhone: text("customer_phone").notNull(),
    city: text("city").notNull(),
    areaType: areaTypeEnum("area_type").notNull(),
    deliveryAddress: text("delivery_address").notNull(),
    productDescription: text("product_description").notNull(),
    productPriceCentimes: integer("product_price_centimes"),
    amountToCollectCentimes: integer("amount_to_collect_centimes"),
    deliveryFeeCentimes: integer("delivery_fee_centimes").notNull(),
    plannedDate: date("planned_date", { mode: "string" }),
    status: orderStatusEnum("status").notNull().default("new"),
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
    deliveredAt: timestamp("delivered_at", { withTimezone: true }),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
  },
  (table) => [
    index("livreson_orders_created_at_idx").on(table.createdAt),
    index("livreson_orders_status_idx").on(table.status),
    index("livreson_orders_merchant_idx").on(table.merchantId),
    index("livreson_orders_area_idx").on(table.areaType),
  ],
);

export const orderStatusHistoryTable = pgTable(
  "livreson_order_status_history",
  {
    id: serial("id").primaryKey(),
    orderId: integer("order_id")
      .notNull()
      .references(() => ordersTable.id, { onDelete: "restrict" }),
    previousStatus: orderStatusEnum("previous_status"),
    newStatus: orderStatusEnum("new_status").notNull(),
    changedAt: timestamp("changed_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    notes: text("notes"),
  },
  (table) => [index("livreson_order_history_order_idx").on(table.orderId)],
);

export const merchantPaymentsTable = pgTable(
  "livreson_merchant_payments",
  {
    id: serial("id").primaryKey(),
    merchantId: integer("merchant_id")
      .notNull()
      .references(() => merchantsTable.id, { onDelete: "restrict" }),
    reference: text("reference").notNull().unique(),
    idempotencyKey: text("idempotency_key").notNull().unique(),
    amountCentimes: integer("amount_centimes").notNull(),
    paymentDate: date("payment_date", { mode: "string" }).notNull(),
    method: paymentMethodEnum("method").notNull(),
    transactionReference: text("transaction_reference"),
    notes: text("notes"),
    status: paymentStatusEnum("status").notNull().default("confirmed"),
    reversedAt: timestamp("reversed_at", { withTimezone: true }),
    reversalReason: text("reversal_reason"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [index("livreson_payments_merchant_idx").on(table.merchantId)],
);

export const appSettingsTable = pgTable("livreson_settings", {
  id: integer("id").primaryKey().default(1),
  businessName: text("business_name").notNull().default("Premium Livreson"),
  phone: text("phone").notNull().default("0718294302"),
  fesFeeCentimes: integer("fes_fee_centimes").notNull().default(1500),
  surroundingFeeCentimes: integer("surrounding_fee_centimes")
    .notNull()
    .default(3000),
  collectionStart: text("collection_start").notNull().default("11:00"),
  collectionEnd: text("collection_end").notNull().default("13:00"),
  currency: text("currency").notNull().default("MAD"),
  timezone: text("timezone").notNull().default("Africa/Casablanca"),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const workflowDaysTable = pgTable(
  "livreson_workflow_days",
  {
    id: serial("id").primaryKey(),
    businessDate: date("business_date", { mode: "string" }).notNull(),
    collectionStartedAt: timestamp("collection_started_at", {
      withTimezone: true,
    }),
    deliveryStartedAt: timestamp("delivery_started_at", {
      withTimezone: true,
    }),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow()
      .$onUpdate(() => new Date()),
  },
  (table) => [
    uniqueIndex("livreson_workflow_days_business_date_idx").on(
      table.businessDate,
    ),
  ],
);

export const insertMerchantSchema = createInsertSchema(merchantsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertMerchant = z.infer<typeof insertMerchantSchema>;
export type Merchant = typeof merchantsTable.$inferSelect;

export const insertOrderSchema = createInsertSchema(ordersTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  deliveredAt: true,
  deletedAt: true,
});
export type InsertOrder = z.infer<typeof insertOrderSchema>;
export type LivresonOrder = typeof ordersTable.$inferSelect;

export const insertPaymentSchema = createInsertSchema(merchantPaymentsTable).omit({
  id: true,
  createdAt: true,
  reversedAt: true,
  reversalReason: true,
});
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type MerchantPayment = typeof merchantPaymentsTable.$inferSelect;
